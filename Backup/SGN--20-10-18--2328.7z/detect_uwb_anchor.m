classdef detect_uwb_anchor < matlab.System
    % Untitled2 Add summary here
    %
    % This template includes the minimum set of functions required
    % to define a System object with discrete state.

    % Public, tunable properties
    properties
        % Process noise
        w_p = 1e-5
        
        % Measurement noise
        v_p = 1e-2
    end

    properties(DiscreteState)
        rec_id      % recorded beacon id
        
        x           % position
        
        P           % error covariance matrix
    end
    
    methods
        % Constructor
        function obj = detect_uwb_anchor(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(obj,nargin,varargin{:});
        end
    end

    methods(Access = protected)
        function setupImpl(~)
            % Perform one-time calculations, such as computing constants
        end

        function p_est = stepImpl(obj, dist_meas, pos_UAV, id)
            
            for ii = 1:length(id)
                % Chack wether the marker id belongs to an already seen
                % marker (and is thus already registered) or not.
                if not(ismember(id(ii), obj.rec_id))
                    % If the id is new add a new entry for the discrete
                    % states equal to the actual measure.

                    obj.rec_id(end+1) = id(ii);

                    obj.x(2:4, end+1) = (pos_UAV(ii,:)).' + [dist_meas(ii); 0; 0];
                    obj.x(1, end) = obj.x(2, end)^2 + obj.x(3, end)^2 + obj.x(4, end)^2;

                    % If i do directly obj.P(:,:,end+1) = eye(4); on the
                    % first iteration, I obtain an array of size (:,:,2)
                    % and not (:,:,1). The if resolves this issue.
                    if sum(size(obj.P)) == 0
                        obj.P(:,:,1) = eye(4);
                    else
                        obj.P(:,:,end+1) = eye(4);
                    end
                    
                    index = length(obj.rec_id);
                else
                    % The id is not new ==> directly kalman filter
                    
                    % Find the index corresponding to the id
                    for jj = 1:length(obj.rec_id)
                        if id(ii) == obj.rec_id(jj)
                            index = jj;
                        end
                    end
                end
                    
                % Measurement
                z = dist_meas(ii)^2 - norm(pos_UAV(ii,:))^2;

                % Observation matrix and covariance matrices
                H = 2 * [1/2,  -pos_UAV(ii,1),  -pos_UAV(ii,2),  -pos_UAV(ii,3)];
                R = obj.v_p;
                Q = diag(obj.w_p*ones(1,4));
                
                % Predict P
                P_pred = obj.P(:,:,index) + Q;
                
                % Kalman equations
                [x_cor, P_cor] = obj.kalman_eq(P_pred, R, H, obj.x(:, index), z);
                
                obj.P(:,:,index) = P_cor;
                
                
                % Update the state and the output
                obj.x(:, index) = x_cor;
                p_est = obj.x(2:4, index).';
            end
        end

        function resetImpl(obj)
            % Initialize / reset discrete-state properties
            
            obj.rec_id = [];
        
            obj.x = [];
        
            obj.P = [];
        end
    end
    
    methods(Static)
        % Kalman equations.
        function [x_corr, P_corr] = kalman_eq(P, R, H, x, z)
            % Innovation covariance
            S = R + H * P * H.';
            
            % Kalman gain
            K = P * H.' / S;
            
            % Error estimate covariance update
            P_corr = P - K * H * P;
            
            x_corr = x + K * ( z - H*x );
        end
    end
end


