%% Description
%
% Generate a waypoint trajectory in a semi-structured environment (manually
% created) and visualize the estimate of the position of the drone.


%% Initialization

clc
clear variables
close all

fprintf('Started. \n \n')


%% Simulation Setup

% Sensors frequencies [Hz]
imuFs = 080;    % IMU (accelerometer and gyroscope)
magFs = 40;     % magnetometer
gpsFs = 5;      % GPS
uwbFs = 20;     % Ultra Wide Band
visFs = 5;      % vision system (ArUco marker)
barFs = 1;      % barometer
altFs = 50;     % altimeter

Ts = 1/imuFs;   % IMU sampling time


%% Initial position and Earth parameters

% Starting position
refloc = [43.70853, 10.4036, 57];                           % Latitude, longitude [°], height [m]
lat_0 = refloc(1);
lon_0 = refloc(2);
alt_0 = refloc(3);

% Earth parameters and their influence on navigation are neglected.

% % Earth rotation rate
% omega_ei_i = 72.92115*10^-6 * [0; 0; 1];                    % Earth angular velocity in ECI [rad/s]
% omega_ie_i = - omega_ei_i;
% omega_ie = 72.92115*10^-6 * [cos(lat_0); 0; -sin(lon_0)];	  % Earth angular velocity in NED [rad/s]
% 
% % WGS84 initialization
% wgs84 = wgs84Ellipsoid;
% re = wgs84.SemimajorAxis;
% eccentricity = wgs84.Eccentricity;
% % Gravity approximation parameters
% g_wgs0 = 9.7803267714;
% g_wgs1 = 0.00193185138639;


%% Generate UAV Trajectory

% Create the waypoint trajectory system object

% Create the waypoints for the trajectory
waypoints = [  0    0  -40;
              30    0  -10;
              50    0   -2;
              50    0   -2;
              80    0   -1.5;   % 5
              80    0   -1.5;
              80   15   -1.5;
              80   15   -1.5;
             110   15   -1.5;
             110   15   -1.5;   % 10
             110   -5   -1.5;
             110   -5   -1.5;
              95   -5   -1.5;
              95   -5   -1.5;
              95  -15   -1.5;   % 15
              95  -15   -1.5;
             110  -15   -1.5];

% Time of arrival (at the waypoint)
waypoint_toa = cumsum([0, 30, 20, 10, 20,     2, 15, 2, 30, 2,     20, 2, 15, 2, 15,     2, 15]);

% Velocity at the waypoint
waypoint_vel = zeros(size(waypoints,1), 3);

% Orientation at the waypoints
waypoint_orient = quaternion([1 0 0 0]) * ones(size(waypoints,1), 1);
waypoint_orient(6:end) = [quaternion([0.7071 0 0 -0.7071]);
                          quaternion([0.7071 0 0 -0.7071]);
                          quaternion([1 0 0 0]);
                          quaternion([1 0 0 0]);
                          quaternion([0.7071 0 0 0.7071]);   % 10
                          quaternion([0.7071 0 0 0.7071]);
                          quaternion([0 0 0 1]);
                          quaternion([0 0 0 1]);
                          quaternion([0.7071 0 0 0.7071]);
                          quaternion([0.7071 0 0 0.7071]);   % 15
                          quaternion([1 0 0 0])
                          quaternion([1 0 0 0])];

% Waypoint trajectory creation
trajData = waypointTrajectory(waypoints, ...
                              'TimeOfArrival', waypoint_toa, ...
                              'Velocities', waypoint_vel, ...
                              'Orientation', waypoint_orient, ...
                              'SampleRate', imuFs);

% The output of the trajectory is in this form:
% [position, orientation, velocity, acceleration, angularVelocity] = trajectory()


% Generate all the trajectory points (slow process).

fprintf('Generating trajectory... \n')

fcnt = 1;

% Number of trajectory points to generate
loopBound = imuFs * waypoint_toa(end);

% Trajectory variables initialization
trajPos = zeros(loopBound, 3);
trajOrient = quaternion([1 0 0 0]) * zeros(loopBound, 1);
trajVel = zeros(loopBound, 3);
trajAcc = zeros(loopBound, 3);
trajAngVel = zeros(loopBound, 3);

while(fcnt <=loopBound)
    [trajPos(fcnt,:), trajOrient(fcnt,:), trajVel(fcnt,:), trajAcc(fcnt,:), trajAngVel(fcnt,:)] = trajData();
    fcnt = fcnt+1;
end

% Complete the generation of the trajectory points (the last one is not generated)
trajPos(end,:) = waypoints(end,:);
trajOrient(end) = waypoint_orient(end,:);
trajVel(end, :) = waypoint_vel(end,:);
trajAcc(end, :) = [0 0 0];
trajAngVel(end, :) = [0 0 0];


fprintf('Trajectory generation complete... \n \n')


% Initialize the random number generator used in the simulation of sensor
% noise.
rng(1)


%% IMU Sensors

imu = imuSensor('accel-gyro-mag', 'SampleRate', imuFs);

% Earth magnetic field in the UAV starting position.
% MATLAB 2020 needed for this command. If a different (older) version is
% being used, you can change the year and the model used (the '2020') to
% make it work for your current version.
magnfield = (wrldmagm(refloc(3), refloc(1), refloc(2), decyear(date, 'dd-mm-yyyy'), '2020') / 1000).';
imu.MagneticField = magnfield;

% Real(istic) Sensors

% % Accelerometer
% imu.Accelerometer.MeasurementRange =  19.6133;
% imu.Accelerometer.Resolution = 0.0023928;
% imu.Accelerometer.ConstantBias = 0.19;
% imu.Accelerometer.NoiseDensity = 0.0012356;
% 
% % Gyroscope
% imu.Gyroscope.MeasurementRange = deg2rad(250);
% imu.Gyroscope.Resolution = deg2rad(0.0625);
imu.Gyroscope.ConstantBias = deg2rad(3.125);
% imu.Gyroscope.AxesMisalignment = 1.5;
% imu.Gyroscope.NoiseDensity = deg2rad(0.025);
% 
% % Magnetometer
% imu.Magnetometer.MeasurementRange = 1000;
% imu.Magnetometer.Resolution = 0.1;
% imu.Magnetometer.ConstantBias = 0;
% imu.Magnetometer.NoiseDensity = 0.3/ sqrt(50);


% Sensor orientations (s_i to body)
% They should be all the same if AHRS
q_sens_acc  = quaternion([1 0 0 0]);
q_sens_gyro = quaternion([1 0 0 0]);
q_sens_magn = quaternion([1 0 0 0]);


%% GPS Sensor

gps = gpsSensor('UpdateRate', gpsFs);
gps.ReferenceLocation = refloc;
gps.DecayFactor = 0.1;              	 % Random walk noise parameter
gps.HorizontalPositionAccuracy = 1.6;
gps.VerticalPositionAccuracy =  3;
gps.VelocityAccuracy = 0.1;


%% Ultra Wide Band Sensor

% The beacons are divided in known and unknown, depending on if they are
% known by the navigation system or not.

% Beacon (anchor) positions and id with known coordinates (by the 
% navigation sys)
known_beacon_pos = [61,  19,  0;      % 1
                    61, -19,  0;      % 2
                    89,  19,  0;      % 3
                    89, -19,  0];     % 4

% TODO: check.
known_beacon_id = linspace(1,size(known_beacon_pos,1),size(known_beacon_pos,1));


% Beacon (anchor) position nad id with unknown coordinates (by the
% navigation sys)
unknown_beacon_pos = [70, +10, 0];

unknown_beacon_id = 1;


% Beacons which have a position already known to thenavigation system.
% This division is only useful to simplify the code.

% UWB sensor system object creation
uwb_known = uwb_sensor('beacon_position', known_beacon_pos, ...
                       'beacon_id', known_beacon_id, ...
                       'error_variance', 0.09, ...
                       'range', 30);


% UWB sensor system object istance
% Simulates only the beacons with unknown position to the nav system.
uwb_unknown = clone(uwb_known);

uwb_unknown.beacon_position = unknown_beacon_pos;
uwb_unknown.beacon_id = unknown_beacon_id;


%% Beacon position detector object

% It is implemented as a simple Kalman filter.

% Object creation
detect_beacon = detect_uwb_anchor;

% The process noise is set to 0 because the beacon is supposed to be fixed
% (in the nav frame).
detect_beacon.w_p = 0;

detect_beacon.v_p = 1e-4;

detect_beacon.threshold = 20;


%% Vision Sensor

% Camera parameters

% Camera detection cone semi-angle [radians]
camera_cone_semi_angle = 40 * pi / 180;

% Maximum distance that the vision sensor is able to measure
camera_max_distance = 40;

% Minimum distance that the vision sensor is able to measure
camera_min_distance = 0.05;

% The noise on both position and orientation is modeled as the sum
% of a constant noise and a noise linear with the distance of the
% target from the camera.
% In addition, the noise, for both orientation and position, is
% different if the component is perpendicular or parallel to the
% line of sight.
% For position, the error is bigger on the parallel component.
noise_perpendicular_position_constant = (0.1)^2;
noise_parallel_position_constant      = (0.2)^2;
noise_perpendicular_position_linear   = (0.2 / camera_max_distance)^2;
noise_parallel_position_linear        = (0.4 / camera_max_distance)^2;

% For orientation, the error is bigger on the perpendicular
% component.
noise_perpendicular_orientation_constant = (2*pi/180)^2;
noise_parallel_orientation_constant      = (1*pi/180)^2;
noise_perpendicular_orientation_linear   = (4*pi/180 / camera_max_distance)^2;
noise_parallel_orientation_linear        = (2*pi/180 / camera_max_distance)^2;

% Camera frame orientation with respect to the body frame,
% specified as euler angles [yaw, pitch, roll].
camera_orientation = [0, -pi/3, 0];

% Optical center position with respect to the body center of mass 
% in the body frame.
% p_cb_b
camera_position = [0.1, 0, 0.1];


% Marker parameters

% Known markers (by the navigation system)
% Marker id
known_marker_id = linspace(1, 4, 4);

% Markers reference frame orientation wrt global frame, specified as
% [yaw, pitch, roll] and in [rad]. Row vector.
known_marker_orientation = [0, 0, 0;
                            0, 0, 0;
                            0, 0, 0];
                  
% Markers position in global frame [m].
known_marker_position = [ 60,   0,   0;
                         100,  -5,   0;
                         110, -15,   0];

% Unknown markers (by the navigation system)
unknown_marker_id = 1;

unknown_marker_orientation = [0 0 0];

unknown_marker_position = [50 0 0];


% Aruco sensor simulator full setup ( ͡ʘ ͜ʖ ͡ʘ)
aruco = aruco_vision_sensor;
aruco.camera_cone_semi_angle = camera_cone_semi_angle;
aruco.camera_max_distance = camera_max_distance;
aruco.camera_min_distance = camera_min_distance;

aruco.noise_perpendicular_position_constant = noise_perpendicular_position_constant;
aruco.noise_parallel_position_constant = noise_parallel_position_constant;
aruco.noise_perpendicular_position_linear = noise_perpendicular_position_linear;
aruco.noise_parallel_position_linear = noise_parallel_position_linear;

aruco.noise_perpendicular_orientation_constant = noise_perpendicular_orientation_constant;
aruco.noise_parallel_orientation_constant = noise_parallel_orientation_constant;
aruco.noise_perpendicular_orientation_linear = noise_perpendicular_orientation_linear;
aruco.noise_parallel_orientation_linear = noise_parallel_orientation_linear;

aruco.camera_orientation = camera_orientation;
aruco.camera_position = camera_position;

aruco.marker_id = known_marker_id;
aruco.marker_orientation = known_marker_orientation;
aruco.marker_position = known_marker_position;


% Unknown aruco sensor simulator
% It is divided from the other only to simplify the coding.
aruco2 = clone(aruco);

aruco2.marker_id = unknown_marker_id;
aruco2.marker_orientation = unknown_marker_orientation;
aruco2.marker_position = unknown_marker_position;


%% Detect marker object

% Object creation
detect_aruco = detect_marker;

% Parameters
detect_aruco.camera_pos = camera_position;
detect_aruco.camera_orient = camera_orientation;
detect_aruco.w_p = 0;
detect_aruco.w_q = 0;

detect_aruco.update_private_properties;


%% Barometer Sensor

bar = barometer_sensor;

bar.wn_variance = 0.5^2;
bar.bi_variance = 0.03^2;
bar.decay_factor = 0.0001;

% The output is quantized
bar.quantization = 0.05;


%% Laser (?) Altimeter Sensor

alt = altimeter_sensor;

alt.wn_variance = 0.05^2;
alt.qwn_variance = 0.3^2 / 7^4;
alt.bi_variance = 0.01^2;
alt.decay_factor = 0.2;

% Minimum and maximum measurable distances
alt.min_alt = 0.1;
alt.max_alt = 5;

% The output is quantized
alt.quantization = 0.001;

% The sensor is supposed to be perfectly perpendicular to the ground and
% with the following displacement relative to body frame
alt.p_0 = [0 0 0.1];


%% Filter setup

% Number of accelerometer and gyroscope measurements which are considered
% together in the Kalman filter. Increase this value to reduce the
% computational cost, at the expense of estimation precision.
decimation_factor = 1;

% Filter call and properties initialization
FUSE = my_navigation_filter;

% Sample rates
FUSE.sample_rate = imuFs;
FUSE.magn_sample_rate = magFs;
FUSE.GPS_sample_rate = gpsFs;
FUSE.uwb_sample_rate = uwbFs;
FUSE.vis_sample_rate = visFs;
FUSE.bar_sample_rate = barFs;
FUSE.alt_sample_rate = altFs;

% Decimation factor
FUSE.decimation_factor = decimation_factor;

% Accel, gyro, magn noise
FUSE.acc_noise = 6e-2;
FUSE.magn_noise = 7.5e-2;
FUSE.gyro_noise = 7.5e-2;

% IMU sensor frames orientation
FUSE.q_sens_acc = q_sens_acc;
FUSE.q_sens_gyro = q_sens_gyro;
FUSE.q_sens_magn = q_sens_magn;

% Gyroscope drift
FUSE.gyro_drift_noise = 2e-4;

% Linear acceleration
FUSE.lin_acc_noise = 1e-6;
FUSE.lin_acc_decay_factor = 0.9;

% Magnetometer disturbance
FUSE.magn_disturbance_noise = 1e-5;
FUSE.magn_disturbance_decay_factor = 0.9;

% GPS
FUSE.GPS_pos_noise = 4e+0;
FUSE.GPS_pos_drift_noise = 1e-5;
FUSE.GPS_vel_noise = 1e-2;

% Acceleration drift (bias)
FUSE.acc_drift_noise = 5e-8;

% UWB
FUSE.uwb_noise = 5e-1;
FUSE.uwb_beacon_position = known_beacon_pos;
FUSE.uwb_beacon_id = known_beacon_id;

% Computer vision
FUSE.camera_orient = camera_orientation;
FUSE.camera_pos = camera_position;
FUSE.marker_id = known_marker_id;
FUSE.marker_orient = known_marker_orientation;
FUSE.marker_pos = known_marker_position;
FUSE.vision_pos_noise = 1e+0;
FUSE.vision_orient_noise = 3e-2;

% Barometer
FUSE.bar_sample_rate = barFs;
FUSE.bar_noise = 1e+0;

% Altimeter
FUSE.alt_sample_rate = altFs;
FUSE.alt_pos = [0 0 0.1];
FUSE.alt_noise = 1e-1;

FUSE.alt_threshold = 0.3;
FUSE.ground_height_noise = 1e-3;


FUSE.init_process_noise = diag([6.092348396e-6*ones(1,3), 7.6154354947e-5*ones(1,3), 9.62361e-3*ones(1,3), 0.6*ones(1,3), 1e-6*ones(1,12), 1]);     % 25x25 matrix

FUSE.magn_field_NED = magnfield.';

FUSE.reference_location = refloc;

FUSE.private_properties_update;


FUSE(1);    % To initialize the discrete state. TODO: eliminate the need for this.


% Initialize some filter states
FUSE.set_initial_state('q', trajOrient(1), ...
                       'gyro_offset', 0*[deg2rad(3.125) deg2rad(3.125) deg2rad(3.125)].', ...
                       'pos', trajPos(1,:).', ...
                       'vel', trajVel(1,:).', ...
                       'acc_bias', -0*[0.19, 0.19, 0.19].');


%% Plots setup

% Colors
default_colors = colororder;

used_colors = [0 0 1;
               1 .647 0;
               1 1 0;
               1 0 1;
               0 1 0;
               0 1 1;
               1 0 0];

% Top view plot
fig1 = figure('Name', 'Top View');

% This is used to avoid calling figure(1) when selecting where to plot.
% This way if the plot is continuously updated, it does not pop up over
% everything.
% Do plot(hax1, ...)
hax1 = axes;

hold on
axis equal
grid on

title('Top View')
xlabel('x-North [m]')
ylabel('y-East [m]')

% Ideal trajectory plot
plot(waypoints(:,1), waypoints(:,2), 'b--o')

% Environment plot
house1 = [ 60,     5;
           60,    20;
           90,    20;
           90,    17.5;
           90,    20;
          120,    20;
          120,     5;
          115,     5;
          120,     5;
          120,   -10;
          105,   -10;
          120,   -10;
          120,   -20;
           90,   -20;
           90,  12.5;
           90,     5;
          105,     5;
           90,     5;
           90,   -20;
           60,   -20;
           60,   -5];
       
plot(house1(:,1), house1(:,2), 'black', 'LineWidth', 3)


% Aruco markers plot
aruco_marker_dim = 500;     % dimension of the aruco marker in the plot

scatter(known_marker_position(:,1), known_marker_position(:,2), aruco_marker_dim, used_colors(1,:), 's', 'LineWidth', 2)   	% dark blue

scatter(hax1, unknown_marker_position(:,1), unknown_marker_position(:,2), aruco_marker_dim, used_colors(7,:), 's', 'LineWidth', 2)

% Aruco markers position estimate container.
aruco_estimate_plot = scatter(hax1, [], []);


% UWB anchors plot
uwb_beacon_dim = 200;

scatter(known_beacon_pos(:,1), known_beacon_pos(:,2), uwb_beacon_dim, used_colors(1,:), 'LineWidth', 2)                       % dark blue

scatter(unknown_beacon_pos(:,1), unknown_beacon_pos(:,2), uwb_beacon_dim, used_colors(7,:), 'LineWidth', 2)                      % red

% UWB beacons position estimate container.
for ii = 1:length(unknown_beacon_id)
    beacon_estimate_plot(ii) = scatter(hax1, [], []);
end


% Estimated trajectory plot
est_traj = animatedline(hax1, 'Color', 'k', 'LineWidth', 1);                                                            % black


% Interface plot
fig2 = figure('Name', 'Interface');

%Interface setup
hold off
axis([0 1 0 1])
daspect([1 1 1])
set(gca,'visible','off')
set(gca,'xtick',[])
set(gca,'ytick',[])


% Initialize the interface
% Interface rectangles dimensions
ann_gps_rect_dim = [.0 .94 .25 .06];
ann_uwb_rect_dim = [.0 .84 .25 .06];
ann_vis_rect_dim = [.0 .74 .31 .06];
ann_alt_rect_dim = [.0 .64 .31 .06];


% GPS signal flag
ann_gps_col = annotation(fig2, 'rectangle', ann_gps_rect_dim, 'FaceColor','red','FaceAlpha',.2);
ann_gps_text = annotation(fig2, 'textbox', ann_gps_rect_dim, 'String', 'GPS signal absent', 'FitBoxToText','off');

% UWB signal flag
ann_uwb_col = annotation(fig2, 'rectangle', ann_uwb_rect_dim, 'FaceColor','red','FaceAlpha',.2);
ann_uwb_text = annotation(fig2, 'textbox', ann_uwb_rect_dim, 'String', 'UWB signal absent', 'FitBoxToText','off');

% Vision signal flag
ann_vis_col = annotation(fig2, 'rectangle', ann_vis_rect_dim, 'FaceColor','red','FaceAlpha',.2);
ann_vis_text = annotation(fig2, 'textbox', ann_vis_rect_dim, 'String', 'No ArUco marker detected', 'FitBoxToText','off');

% Barometer signal flag
ann_alt_col = annotation(fig2, 'rectangle', ann_alt_rect_dim, 'FaceColor','red','FaceAlpha',.2);
ann_alt_text = annotation(fig2, 'textbox', ann_alt_rect_dim, 'String', 'Altimeter signal absent', 'FitBoxToText','off');


%% Initialize Scopes

useErrScope = true;     % Turn on the streaming error plot

if useErrScope
    errscope = HelperScrollingPlotter(...
        'NumInputs', 4, ...
        'TimeSpan', 10, ...
        'SampleRate', imuFs, ...
        'YLabel', {'degrees', ...
        'meters', ...
        'meters', ...
        'meters'}, ...
        'Title', {'Quaternion Distance', ...
        'Position X Error', ...
        'Position Y Error', ...
        'Position Z Error'}, ...
        'YLimits', ...
        [   0,  5
           -2,  2
           -2,  2
           -2,  2]);
end

f = gcf;    % current figure handle


%% Simulation Loop

% Loop setup
secondsToSimulate = waypoint_toa(end);
numsamples = secondsToSimulate*imuFs;

loopBound = floor(numsamples);
loopBound = floor(loopBound/imuFs)*imuFs;	% ensure enough IMU Samples

% Log data for final metric computation.
pqorient = quaternion.zeros(loopBound,1);
pqpos = zeros(loopBound,3);
pqvel = zeros(loopBound,3);
pqacc = zeros(loopBound,3);

% If true the corresponding part of the state covariance matrix has already
% been updated. It is updated if and only if there is a measure which
% activates a Kalman correction.
P_1_already_predicted = false;
P_2_already_predicted = false;

% The starting orientation and position is supposed to be exactly known.
pqorient(1,:) = trajOrient(1);
pqpos(1,:) = trajPos(1,:);
pqvel(1,:) = trajVel(1,:);


% Parameters used to update the figure colors.

% Flags, true if the corresponding sensor measurement is received or not
% accessible
% Used to update the interface
is_gps = false;
is_uwb = false;
is_vis = false;
is_alt = false;
is_vis_detect = false;

% Number of uwb anchors in range
uwb_known_beacon_number = 0;

% Memory of the uwb beacons indexes in range, used to change their color in
% the plot.
unobstr_known_beacon_id_old = [];
uwb_beacon_id_old = [];

% Memory of the uwb unknown beacons indexes in range, used to change their
% color in the plot.
unobstr_unknown_beacon_id_old = [];
uwb_beacon_detect_id_old = [];

% Memory of the unknown  ArUco markers indexes in range, used to change
% their color in the plot.
vis_id_old = [];
vis_detect_id_old = [];


% Saved filter states
saved_acc_bias = zeros(loopBound, 3);
saved_lin_acc = zeros(loopBound, 3);
saved_magn_dist = zeros(loopBound, 3);
saved_ground_height = zeros(loopBound, 1);

fig3 = figure(3);
hax3 = axes;

fig4 = figure(4);
hax4 = axes;

a_g_b_1 = animatedline(hax3, 'Color', default_colors(1,:));
a_g_b_2 = animatedline(hax3, 'Color', default_colors(2,:));
a_g_b_3 = animatedline(hax3, 'Color', default_colors(3,:));

a_l_a_e_1 = animatedline(hax4, 'Color', default_colors(1,:));
a_l_a_e_2 = animatedline(hax4, 'Color', default_colors(2,:));
a_l_a_e_3 = animatedline(hax4, 'Color', default_colors(3,:));



temp = [];


% Loop variable
fcnt = 1;

while(fcnt <=loopBound-1)
    % Simulate the IMU data from the current pose.
    % [position, orientation, velocity, acceleration, angularVelocity] = trajectory()
    [accel, gyro, mag] = imu(trajAcc(fcnt,:), ...
                             trajAngVel(fcnt, :), ...
                             trajOrient(fcnt));
	
	% Sensor output
    % accel = - f_b;
    % gyro = omega_ib_b;
	
	% Rotate the outputs because the sensor frame does not coincide with
	% the body frame.
    accel = quat_rot(accel, conj(q_sens_acc));      % conj because we rotate from the boody frame to the sensor frame
    gyro = quat_rot(gyro, conj(q_sens_gyro));
    mag = quat_rot(mag, conj(q_sens_magn));
    
    
    % The filter predict step is done at the IMU (accelerometer and gyro)
    % frequency.
    [pqorient(fcnt+1), pqpos(fcnt+1, :), pqvel(fcnt+1, :)] = FUSE.predict(gyro, accel);
    
    
    % Update the top view
    addpoints(est_traj,pqpos(fcnt+1, 1),pqpos(fcnt+1, 2));
    
    drawnow limitrate   % limits the maximum update frequency
    
    
    addpoints(a_g_b_1,fcnt, FUSE.getDiscreteState.gyro_offset(1));
    addpoints(a_g_b_2,fcnt, FUSE.getDiscreteState.gyro_offset(2));
    addpoints(a_g_b_3,fcnt, FUSE.getDiscreteState.gyro_offset(3));
    
    addpoints(a_l_a_e_1,fcnt, accel(1)-9.81*FUSE.getDiscreteState.lin_accel_prior(1));
    addpoints(a_l_a_e_2,fcnt, accel(2)-9.81*FUSE.getDiscreteState.lin_accel_prior(2));
    addpoints(a_l_a_e_3,fcnt, accel(3)-9.81-9.81*FUSE.getDiscreteState.lin_accel_prior(3));  
    
    drawnow limitrate   % limits the maximum update frequency
    
    
    % P_i is updated only if there is the need to perform a correction step
    % using that specific part of P. This justifies the need for the if
    % cycle on the update of P_i and the variables P_i_already_predicted.
    % Some useless optimizations on the cycle and on the variable update
    % have been performing by commenting an unused line.
    
    % The correction using the accelerometer data is done every
    % decimation_factor sample times.
    if mod(fcnt, fix(decimation_factor)) == 0
        % Predict P
        %if not(P_1_already_predicted)
            FUSE.predict_P_1;
            P_1_already_predicted = true;
        %end
        
        % Accelerometer correction
        [pqorient(fcnt+1), ~] = FUSE.fuse_accel;
    end
    
    
    % Magnetometer correction
    if mod(fcnt, fix(imuFs/magFs)) == 0
        % Predict P, only if it has not been already done
        if not(P_1_already_predicted)
            FUSE.predict_P_1;
            %P_1_already_predicted = true;
        end
        
        % Fuse the magnetomer measurement
        [pqorient(fcnt+1), ~] = FUSE.fuse_magn(mag);
    end
    
    
    % Error scope variables
    fusedOrient =  pqorient(fcnt+1,:);
    fusedPos =  pqpos(fcnt+1,:);
    
    % Compute the errors and plot.
    if useErrScope
        orientErr = rad2deg(dist(fusedOrient, ...
            trajOrient(fcnt) ));
        posErr = fusedPos - trajPos(fcnt,:);
        errscope(orientErr, posErr(1), posErr(2), posErr(3));
    end
    
    
%     % GPS correction step (at the GPS sample rate)
%     if mod(fcnt, fix(imuFs/gpsFs)) == 0
%         % Update the interface plot, only if its state is changed
%         if is_gps ~= yes_gps(trajPos(fcnt,:))
%             is_gps = yes_gps(trajPos(fcnt,:));
%             
%             if is_gps
%                 % GPS available
%                 figure(2)
%                 delete(ann_gps_col);
%                 delete(ann_gps_text);
%                 
%                 ann_gps_col = annotation(fig2, 'rectangle', ann_gps_rect_dim, 'FaceColor','green','FaceAlpha',.2);
%                 ann_gps_text = annotation(fig2, 'textbox', ann_gps_rect_dim, 'String', 'GPS signal received', 'FitBoxToText','off');
%             else
%                 % GPS unavailable
%                 figure(2)
%                 delete(ann_gps_col);
%                 delete(ann_gps_text);
%                 
%                 ann_gps_col = annotation(fig2, 'rectangle', ann_gps_rect_dim, 'FaceColor','red','FaceAlpha',.2);
%                 ann_gps_text = annotation(fig2, 'textbox', ann_gps_rect_dim, 'String', 'GPS signal absent', 'FitBoxToText','off');
%             end
%         end
%         
%         % Fuse the gps signal, only if available
%         if is_gps
%             % Predict P_2, only if it has not been already done
%             %if not(P_2_already_predicted)
%                 FUSE.predict_P_2;
%                 P_2_already_predicted = true;
%             %end
%         
%             % Simulate the GPS output based on the current pose.
%             [lla, gpsvel] = gps( trajPos(fcnt,:), trajVel(fcnt,:) );
%     
%             % Correct the filter states based on the GPS data measurements.
%             [pqpos(fcnt+1, :), pqvel(fcnt+1, :)] = FUSE.fuse_GPS(lla, gpsvel);
%         end
%     end
%     
%     
%     % UWB correction step
%     if mod(fcnt, fix(imuFs/uwbFs)) == 0
%         % Returns a flag if in the current "room" there are beacons which
%         % are not obstructed by walls, and their ids.
%         [y1, unobstr_known_beacon_id] = yes_uwb(trajPos(fcnt,:));
%         
%         % Fuse the UWB signal, if available
%         if y1
%             %Simulate sensor
%             [uwb_meas_dist, uwb_beacon_id, uwb_index] = uwb_known(trajPos(fcnt,:), unobstr_known_beacon_id);
%             
%             % Predict P_2, only if it has not been already done
%             if isempty(uwb_beacon_id) == false
%                 if not(P_2_already_predicted)
%                     FUSE.predict_P_2;
%                     %P_2_already_predicted = true;
%                 end
%                 
%                 
%                 [pqpos(fcnt+1, :), pqvel(fcnt+1, :)] = FUSE.fuse_uwb(uwb_meas_dist, uwb_beacon_id);
%             end
%         else
%             uwb_beacon_id = [];
%             uwb_index = [];
%         end
%         
%         % Update the interface plot, only if its state is changed
%         if is_uwb ~= ( yes_uwb(trajPos(fcnt,:)) & not(isempty(uwb_beacon_id)) ) ... % the uwb is active AND at least an anchor is in range
%                 || uwb_known_beacon_number ~= length(uwb_beacon_id)
%             is_uwb = ( yes_uwb(trajPos(fcnt,:)) & not(isempty(uwb_beacon_id)) );
%             uwb_known_beacon_number = length(uwb_beacon_id);
%             
%             if is_uwb
%                 % UWB available
%                 figure(2)
%                 delete(ann_uwb_col);
%                 delete(ann_uwb_text);
%                 
%                 if length(uwb_beacon_id) >= 4
%                     ann_uwb_col = annotation(fig2, 'rectangle', ann_uwb_rect_dim, 'FaceColor','green','FaceAlpha',.2);
%                     ann_uwb_text = annotation(fig2, 'textbox', ann_uwb_rect_dim, 'String', 'UWB signal received', 'FitBoxToText','off');
%                 else
%                     ann_uwb_col = annotation(fig2, 'rectangle', ann_uwb_rect_dim, 'FaceColor','yellow','FaceAlpha',.2);
%                     ann_uwb_text = annotation(fig2, 'textbox', ann_uwb_rect_dim, 'String', 'UWB signal received', 'FitBoxToText','off');
%                 end
%             else
%                 % UWB unavailable
%                 figure(2)
%                 delete(ann_uwb_col);
%                 delete(ann_uwb_text);
%                 
%                 ann_uwb_col = annotation(fig2, 'rectangle', ann_uwb_rect_dim, 'FaceColor','red','FaceAlpha',.2);
%                 ann_uwb_text = annotation(fig2, 'textbox', ann_uwb_rect_dim, 'String', 'UWB signal absent', 'FitBoxToText','off');
%             end
%         end
%         
%         
%         % Change the color of the UWB anchors depending on their state.
%         % Legend:   dark blue:      known, obstructed
%         %           light blue:     known, not obstructed
%         %           green:          known, received
%         %           red:            unknown, not received
%         %           purple:         unknown, received
%         %           orange:         unknown estimate
%         if length(unobstr_known_beacon_id) ~= length(unobstr_known_beacon_id_old) || length(uwb_beacon_id) ~= length(uwb_beacon_id_old)
%             unobstr_known_beacon_id_old = unobstr_known_beacon_id;
%             uwb_beacon_id_old = uwb_beacon_id;
%             
%             % Reset the color
%             scatter(hax1, known_beacon_pos(:,1), known_beacon_pos(:,2), uwb_beacon_dim, used_colors(1,:), 'LineWidth', 2)
%             
%             % Plot the not obscured ones
%             accessible_uwb_plot = scatter(hax1, known_beacon_pos(unobstr_known_beacon_id_old,1), known_beacon_pos(unobstr_known_beacon_id_old,2), uwb_beacon_dim, used_colors(6,:), 'LineWidth', 2);
%             
%             % Plot the received ones
%             visible_uwb_plot = scatter(hax1, known_beacon_pos(uwb_index,1), known_beacon_pos(uwb_index,2), uwb_beacon_dim, used_colors(5,:), 'LineWidth', 2);
%         elseif sum(unobstr_known_beacon_id ~= unobstr_known_beacon_id_old) || sum(uwb_beacon_id ~= uwb_beacon_id_old)
%             unobstr_known_beacon_id_old = unobstr_known_beacon_id;
%             uwb_beacon_id_old = uwb_beacon_id;
%             
%             % Reset the color
%             scatter(hax1, known_beacon_pos(:,1), known_beacon_pos(:,2), uwb_beacon_dim, used_colors(1,:), 'LineWidth', 2)
%             
%             % Plot the not obscured ones
%             accessible_uwb_plot = scatter(hax1, known_beacon_pos(unobstr_known_beacon_id_old,1), known_beacon_pos(unobstr_known_beacon_id_old,2), uwb_beacon_dim, used_colors(6,:), 'LineWidth', 2);
%             
%             % Plot the received ones
%             visible_uwb_plot = scatter(hax1, known_beacon_pos(uwb_index,1), known_beacon_pos(uwb_index,2), uwb_beacon_dim, used_colors(5,:), 'LineWidth', 2);
%         end
%     end
%     
%     
%     % UWB beacon detect step. This is done at a lower frequency compared
%     % to the uwb frequency.
%     if mod(fcnt, 1 * fix(imuFs/uwbFs)) == 0
%         % Returns a flag if in the current "room" there are beacons which
%         % are not obstructed by walls, and their ids.
%         [y1u, unobstr_unknown_beacon_id] = yes_uwb_unknown(trajPos(fcnt,:));
%         
%         % Detect the UWB anchor position, if the signal is available.
%         if y1u
%             %Simulate unknown sensor
%             [uwb_unkn_meas_dist, uwb_unkn_beacon_id, uwb_unkn_index] = uwb_unknown(trajPos(fcnt,:), unobstr_unknown_beacon_id);
%             
%             % Detect the beacon only if there is a measure available
%             if isempty(uwb_unkn_beacon_id) == false
%                 [uwb_anchor, dir, rnk] = detect_beacon(uwb_unkn_meas_dist, pqpos(fcnt, :), uwb_unkn_beacon_id);
%                 
% %                 for jj = 1:length(rnk)
% %                     if not(rnk == 0)
% %                         [pqpos(fcnt+1, :), pqvel(fcnt+1, :)] = FUSE.fuse_unknown_uwb(uwb_unkn_meas_dist, uwb_anchor, dir, rnk);
% %                     end
% %                 end
%             end
%             
%             % Draw the estimate.
%             if mod(fcnt, 5 * fix(imuFs/uwbFs)) == 0
%                 for ii = 1:length(uwb_unkn_beacon_id)
%                     delete(beacon_estimate_plot(uwb_unkn_beacon_id(ii)));
%                 
%                     beacon_estimate_plot(uwb_unkn_beacon_id(ii)) = scatter(hax1, uwb_anchor(ii, 1), uwb_anchor(ii, 2), uwb_beacon_dim, used_colors(2,:), 'LineWidth', 2);
%                 end
%             end
%         else
%             uwb_unkn_beacon_id = [];
%             uwb_unkn_index = [];
%         end
%     end
%     
%     % UWB beacon detect plot step. This is done at an even lower frequency
%     % compared to the uwb frequency.
%     if mod(fcnt, 5 * fix(imuFs/uwbFs)) == 0
%         
%     % Change the color of the UWB anchors depending on their state.
%         % Legend:   dark blue:      known, obstructed
%         %           light blue:     known, not obstructed
%         %           green:          known, received
%         %           red:            unknown, not received
%         %           purple:         unknown, received
%         %           orange:         unknown estimate
%         if length(unobstr_unknown_beacon_id) ~= length(unobstr_unknown_beacon_id_old) || length(uwb_unkn_beacon_id) ~= length(uwb_beacon_detect_id_old)
%             unobstr_unknown_beacon_id_old = unobstr_unknown_beacon_id;
%             uwb_beacon_detect_id_old = uwb_unkn_beacon_id;
%             
%             % Reset the color
%             scatter(hax1, unknown_beacon_pos(:,1), unknown_beacon_pos(:,2), uwb_beacon_dim, used_colors(7,:), 'LineWidth', 2)
%             
%             % Plot the received ones
%             visible_uwb_plot = scatter(hax1, unknown_beacon_pos(uwb_unkn_index,1), unknown_beacon_pos(uwb_unkn_index,2), uwb_beacon_dim, used_colors(4,:), 'LineWidth', 2);
%             
%         elseif sum(unobstr_unknown_beacon_id ~= unobstr_unknown_beacon_id_old) || sum(uwb_unkn_beacon_id ~= uwb_beacon_detect_id_old)
%             unobstr_unknown_beacon_id_old = unobstr_unknown_beacon_id;
%             uwb_beacon_detect_id_old = uwb_unkn_beacon_id;
%             
%             % Reset the color
%             scatter(hax1, unknown_beacon_pos(:,1), unknown_beacon_pos(:,2), uwb_beacon_dim, used_colors(7,:), 'LineWidth', 2)
%             
%             % Plot the received ones
%             visible_uuwb_plot = scatter(hax1, unknown_beacon_pos(uwb_unkn_index,1), unknown_beacon_pos(uwb_unkn_index,2), uwb_beacon_dim, used_colors(4,:), 'LineWidth', 2);
%         end
%         
%     end
% 
% 
%     % Vision correction step
%     if mod(fcnt, fix(imuFs/visFs)) == 0
%         % Simulate sensor
%         [Tmc, vis_id, vis_index] = aruco(trajPos(fcnt,:), trajOrient(fcnt));
%         
%         % Predict P_2, only if it has not been already done
%         if isempty(vis_id) == false
%             if not(P_2_already_predicted)
%                 FUSE.predict_P_2;
%                 P_2_already_predicted = true;
%             end
%         
%             [pqorient(fcnt+1), pqpos(fcnt+1, :), pqvel(fcnt+1, :), ~] = FUSE.fuse_vis(Tmc, vis_id);
%         end
%         
%         % Update the interface plot, only if its state is changed
%         if is_vis ~= not(isempty(vis_id))
%             is_vis = not(isempty(vis_id));
%             
%             if is_vis
%                 % Marker detected
%                 figure(2)
%                 delete(ann_vis_col);
%                 delete(ann_vis_text);
%                 
%                 ann_vis_col = annotation(fig2, 'rectangle', ann_vis_rect_dim, 'FaceColor','green','FaceAlpha',.2);
%                 ann_vis_text = annotation(fig2, 'textbox', ann_vis_rect_dim, 'String', 'ArUco marker detected', 'FitBoxToText','off');
%             else
%                 % No marker detected
%                 figure(2)
%                 delete(ann_vis_col);
%                 delete(ann_vis_text);
%                 
%                 ann_vis_col = annotation(fig2, 'rectangle', ann_vis_rect_dim, 'FaceColor','red','FaceAlpha',.2);
%                 ann_vis_text = annotation(fig2, 'textbox', ann_vis_rect_dim, 'String', 'No ArUco marker detected', 'FitBoxToText','off');
%             end
%         end
%         
%         % Change the color of the vis markers depending on their state.
%         % Legend:   dark blue:      known, not observed
%         %           green:          known, observed
%         %           red:            unknown, not observed
%         %           purple:         unknown, received
%         %           orange:         unknown estimate
%         if length(vis_id) ~= length(vis_id_old)
%             vis_id_old = vis_id;
%             
%             % Reset the color
%             scatter(hax1, known_marker_position(:,1), known_marker_position(:,2), aruco_marker_dim, used_colors(1,:), 's', 'LineWidth', 2)
%             
%             % Plot the received ones
%             scatter(hax1, known_marker_position(vis_index,1), known_marker_position(vis_index,2), aruco_marker_dim, used_colors(5,:), 's', 'LineWidth', 2)
%         elseif sum(vis_id ~= vis_id_old)
%             vis_id_old = vis_id;
%             
%             % Reset the color
%             scatter(hax1, known_marker_position(:,1), known_marker_position(:,2), aruco_marker_dim, used_colors(1,:), 's', 'LineWidth', 2)
%             
%             % Plot the received ones
%             scatter(hax1, known_marker_position(vis_index,1), known_marker_position(vis_index,2), aruco_marker_dim, used_colors(5,:), 's', 'LineWidth', 2)
%         end
%     end
% 
% 
%     % Aruco marker detection step
%     if mod(fcnt, fix(imuFs/visFs)) == 0
%         % Simulate sensor (only markers with unknown position)
%         [Tmc, vis_detect_id, vis_index] = aruco2(trajPos(fcnt,:), trajOrient(fcnt));
%         
%         if not(isempty(vis_detect_id))
%             [marker_p_est, marker_q_est] = detect_aruco(Tmc, vis_detect_id, pqpos(fcnt, :), pqorient(fcnt));
% 
%             for ii = 1:length(vis_index)
%                 delete(aruco_estimate_plot(vis_index(ii)));
%                 
%                 aruco_estimate_plot(vis_index(ii)) = scatter(hax1, marker_p_est(vis_index(ii), 1), marker_p_est(vis_index(ii), 2), aruco_marker_dim, used_colors(2,:), 's', 'LineWidth', 2);
%             end
%         end
%         
%         % Change the color of the vis markers depending on their state.
%         % Legend:   dark blue:      known, not observed
%         %           green:          known, observed
%         %           red:            unknown, not observed
%         %           purple:         unknown, received
%         %           orange:         unknown estimate
%         if length(vis_detect_id) ~= length(vis_detect_id_old)
%             vis_detect_id_old = vis_detect_id;
%             
%             % Reset the color
%             scatter(hax1, unknown_marker_position(:,1), unknown_marker_position(:,2), aruco_marker_dim, used_colors(7,:), 's', 'LineWidth', 2)
%             
%             % Plot the received ones
%             scatter(hax1, unknown_marker_position(vis_index,1), unknown_marker_position(vis_index,2), aruco_marker_dim, used_colors(4,:), 's', 'LineWidth', 2)
%         elseif sum(vis_detect_id ~= vis_detect_id_old)
%             vis_detect_id_old = vis_detect_id;
%             
%             % Reset the color
%             scatter(hax1, unknown_marker_position(:,1), unknown_marker_position(:,2), aruco_marker_dim, used_colors(7,:), 's', 'LineWidth', 2)
%             
%             % Plot the received ones
%             scatter(hax1, unknown_marker_position(vis_index,1), unknown_marker_position(vis_index,2), aruco_marker_dim, used_colors(4,:), 's', 'LineWidth', 2)
%         end
%     end
%     
%     
%     % Barometer correction step
%     if mod(fcnt, fix(imuFs/barFs)) == 0
%         % Predict P_2, only if it has not been already done
%         if not(P_2_already_predicted)
%             FUSE.predict_P_2;
%             P_2_already_predicted = true;
%         end
%         
%         % Simulate sensor
%         bar_h_meas = bar(trajPos(fcnt,:));
%         
%         % Fuse the sensor measurement
%         pqpos(fcnt+1, 3) = FUSE.fuse_bar(bar_h_meas);
%     end
%     
%     
%     % Altimeter correction step
%     if mod(fcnt, fix(imuFs/altFs)) == 0
%         % Simulate sensor
%         alt_h_meas = alt(trajPos(fcnt,:), trajOrient(fcnt,:));
%         
%         if fcnt>5500
%             alt_h_meas = alt_h_meas - 1;
%         end
%         
%         % Predict P_2, only if it has not been already done
%         if not(isnan(alt_h_meas))
%             if not(P_2_already_predicted)
%                 FUSE.predict_P_2;
%                 %P_2_already_predicted = true;  % Commented if and only if it is the last one
%             end
%             
%             pqpos(fcnt+1, 3) = FUSE.fuse_alt(alt_h_meas);
%         end
%         
%         
%         % Update the interface plot, if necessary
%         if is_alt ~= not(isnan(alt_h_meas))
%             is_alt = not(isnan(alt_h_meas));
%             
%             if is_alt
%                 % Ground detected
%                 figure(2)
%                 delete(ann_alt_col);
%                 delete(ann_alt_text);
%                 
%                 ann_alt_col = annotation(fig2, 'rectangle', ann_alt_rect_dim, 'FaceColor','green','FaceAlpha',.2);
%                 ann_alt_text = annotation(fig2, 'textbox', ann_alt_rect_dim, 'String', 'Ground detected', 'FitBoxToText','off');
%             else
%                 % No ground detected
%                 figure(2)
%                 delete(ann_alt_col);
%                 delete(ann_alt_text);
%                 
%                 ann_alt_col = annotation(fig2, 'rectangle', ann_alt_rect_dim, 'FaceColor','red','FaceAlpha',.2);
%                 ann_alt_text = annotation(fig2, 'textbox', ann_alt_rect_dim, 'String', 'No ground detected', 'FitBoxToText','off');
%             end
%         end
%     end
    
    
    % Saved filter states
    saved_acc_bias(fcnt,:) = (FUSE.getDiscreteState.acc_bias).';
    saved_lin_acc(fcnt,:) = (FUSE.getDiscreteState.lin_accel_prior).';
    saved_magn_dist(fcnt,:) = (FUSE.getDiscreteState.magn_dist).';
    saved_ground_height(fcnt) = (FUSE.getDiscreteState.ground_height);
    
    
    % Reset these variables to false
    P_1_already_predicted = false;
    P_2_already_predicted = false;
    
    
    % Increase the counter
    fcnt = fcnt + 1;
end


%% Error Metric Computation
% Position and orientation estimates were logged throughout the
% simulation. Now compute an end-to-end root mean squared error for both
% position and orientation.

posd = pqpos(1:loopBound,:) - trajPos( 1:loopBound, :);

% For orientation, quaternion distance is a much better alternative to
% subtracting Euler angles, which have discontinuities. The quaternion
% distance can be computed with the |dist| function, which gives the
% angular difference in orientation in radians. Convert to degrees
% for display in the command window. 

quatd = rad2deg(dist(pqorient(1:loopBound), trajOrient(1:loopBound)) );

% Display RMS errors in the command window.
fprintf('\n\nEnd-to-End Simulation Position RMS Error\n');
msep = sqrt(mean(posd.^2));
fprintf('\tX: %.2f , Y: %.2f, Z: %.2f   (meters)\n\n',msep(1), ...
    msep(2), msep(3));

fprintf('End-to-End Quaternion Distance RMS Error (degrees) \n');
fprintf('\t%.2f (degrees)\n\n', sqrt(mean(quatd.^2)));


%% Quaternions

% CONVENTION: Quaternion (used by MATLAB) (Hamilton convention)
%	q = (q_scalar, q_vectorial) = (q_w, q_v) = (q_w, q_x, q_y, q_z)
%   Right-handed: ij = k
%   Passive: rotate frames (not vectors)
%   Local-to-Global: q = q_GL = q_L2G
%                    x_G = q * x_L * conj(q)

% CONVENTION: Euler angles (used by MATLAB):
%   eul = [yaw (z), pitch (y), roll (x)] (in this order)
%   rotation order = ZYX: Rz -> Ry -> Rx

% Quaternions are used to avoid singularities in the representation of the
% orientation.

% Alternative method (less computational cost, worse accuracy).
% Uncomment if you want to use this one and comment the other function.
% function [qt_p] = quat_updt(qt, omega, Ts)
%     % Euler approximation
%     qt_p = qt + 1/2*Ts*quaternion([0,omega])*qt;
%     
%     % Output quaternion normalization, it is necessary in this case.
%     qt_p = 1/norm(qt_p) * qt_p;
% end

% Alternative method (small computational cost, medium accuracy).
% Uncomment if you want to use this one and comment the other function.
% function [qt_p] = quat_updt(qt, omega, Ts)
%     % Euler approximation
%     qt_p = quaternion([1,1/2*Ts*omega]) * qt;
%     
%     % Output quaternion normalization, it is necessary in this case.
%     qt_p = 1/norm(qt_p) * qt_p;
% end

% function [qt_p] = quat_updt(qt, omega, Ts)
% % Quaternion update function, uses the quaternion exponential method.
%     qt_p = exp(1/2*Ts*quaternion([0,omega]))*qt;
%     
%     % The normalization should be unnecessary with this method, it is
%     % still used to prevent the accumulation of numerical errors from
%     % affecting the quaternion unit norm.
%     qt_p = 1/norm(qt_p) * qt_p;
% end


% Rotation with quaternions
function v_out = quat_rot(v, q)
    quat_v = quaternion([0, v(1), v(2), v(3)]);
    
    quat_v_out = q * quat_v * conj(q);
    
    % Quaternion parts extraction
    [~, part1, part2, part3] = parts(quat_v_out);
    
    % With this way, the output is in the same form of the input (row or
    % column vector)
    v(1) = part1;
    v(2) = part2;
    v(3) = part3;
    
    v_out = v;
end


%% Available sensors

% Returns true if the drone is in a zone where the GPS is available.
function flag = yes_gps(pos)
    if (pos(1) > 60 ) && (pos(1) < 120) && (pos(2) > - 20) && (pos(2) < 20)
        flag = false;
    else
        flag = true;
    end
end

% If the drone is in a zone where UWB is available returns true, and the
% available beacons (which may still be too far away)
function [flag, id] = yes_uwb(pos)
    if (pos(1) > 60 ) && (pos(1) < 90) && (pos(2) > - 20) && (pos(2) < 20)
        flag = true;
        id = linspace(1,4,4);
    else
        flag = false;
        id = [];
    end
end

% If the drone is in a zone where UWB is available returns true, and the
% available beacons (which may still be too far away)
function [flag, id] = yes_uwb_unknown(pos)
    if (pos(1) > 60 ) && (pos(1) < 90) && (pos(2) > - 20) && (pos(2) < 20)
        flag = true;
        id = 1;
    else
        flag = false;
        id = [];
    end
end


%% Rotations

% CONVENTION: rotation matrices nomenclature
%	Cnb corresponds to a change of the reference frame from frame b to
%   frame n.
%   v_n = Cnb * v_b
%	Cnb = C_b2n = C_b_n

% function out = rotCni(lat, long, time, omega_ie)
% % Rotation matrix from the ECI frame to the navigation frame.
%     lat = lat*pi/180;
%     long = long*pi/180;
%     
%     lon = long + omega_ie*time;
% 
%     out = [[-sin(lat)*cos(lon), -sin(lat)*sin(lon), cos(lat)];
%            [-sin(lon), cos(lon), 0];
%            [-cos(lat)*cos(lon), -cos(lat)*sin(lon), -sin(lat)]];
% end
% 
% function out = rotCnb(eul)
% % Rotation matrix from the body frame to the navigation frame after a
% % yaw-pitch-roll rotation (ZYX).
%     yaw = eul(1);
%     pitch = eul(2);
%     roll = eul(3);
% 
%     out = ( rotCx(roll)*rotCy(pitch)*rotCz(yaw) ).';
% end
% 
% function out = rotCx(ang)
%     out = [[1, 0, 0];
%            [0, cos(ang), sin(ang)];
%            [0, -sin(ang), cos(ang)]];
% end
% 
% function out = rotCy(ang)
%     out = [[cos(ang), 0, -sin(ang)];
%            [0, 1, 0];
%            [sin(ang), 0, cos(ang)]];
% end
% 
% function out = rotCz(ang)
%     out = [[cos(ang), sin(ang), 0];
%            [-sin(ang), cos(ang), 0];
%            [0, 0, 1]];
% end


%% Earth

% function [rn, rm, g] = ellwgs84(re, eccentricity, lat, h, g_wgs0, g_wgs1)
%     rn = re/(1-eccentricity^2*sin(lat)^2)^0.5;                      % R_normal
%     rm = rn * (1-eccentricity^2)/(1-eccentricity^2*sin(lat)^2);     % R_meridian
%     
%     g = g_wgs0 * (1 + g_wgs1 * sin(lat)^2)/(1 - eccentricity^2 * sin(lat)^2) * re^2/(re + h)^2;
% end
% 
% function [lat, lon] = coord_updt(coord, v_n, v_e, rn, rm, Ts)
% 
%     % v_n = v_North     rn = R_normal       Ts = sampling time
%     % v_e = v_East      rm = R_meridian
% 
%     lat = coord(1);
%     lon = coord(2);
%     h = coord(3);
% 
%     latd = v_n / (rm + h);
%     lond = v_e / ((rn + h) * cos(lat));
%     
%     lat = lat + latd * Ts;
%     lon = lon + lond * Ts;
% end
% 
% function omega_en_n = x2omega_en(lat, h, v_n, v_e)
%     latd = v_n / (rm + h);
%     lond = v_e / ((rn + h) * cos(lat));
% 
%     omega_en_n = [ lond * cos(lat);
%                   -latd;
%                   -lond * sin(lat)];
% end

