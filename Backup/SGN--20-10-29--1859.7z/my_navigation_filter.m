classdef my_navigation_filter < matlab.System
    % ( ͡° ͜ʖ ͡°)
    % Fusion of accelerometer, gyroscope, magnetometer, GPS (position and
    % velocity), UWB (with known anchors), computer vision (ArUco markers is known
    % positions), barometer and altimeter.
    % Indirect Quaternion-Based Sequential Extended Kalman Filter

    % Public, tunable properties
    properties
        % IMU
    	sample_rate = 100                       % [Hz]           
        decimation_factor = 1                   % Number of IMU samples joined together to reduce the computational cost
        decimation_factor_max = 16
        
        % Accelerometer
        acc_noise = 0.00019247                  % [(m/s^2)^2]
        acc_drift_noise = 1e-13                 % [(m/s^2)^2]
        lin_acc_noise = 0.0096236               % [(m/s^2)^2]
        lin_acc_decay_factor = 0.5              % if the linear acceleration is quickly changing set to a low value; ∈ [0, 1)
        gravity_limits = [0.75, 1.5]            % [%] if the norm of the measured gravity ∈ to this interval, this 
                                                % measure is used to correct the orientation estimate
        q_sens_acc = quaternion([1 0 0 0])      % orientation of the acceleration sensor frame wrt body frame
        
        % Gyroscope
        gyro_noise = 9.1385e-3                  % [(rad/s)^2]
        gyro_drift_noise = 3.0462e-13           % [(rad/s)^2]
        q_sens_gyro = quaternion([1 0 0 0])      % orientation of the gyroscope sensor frame wrt body frame
        
        % Magnetometer
        magn_sample_rate = 50                   % [Hz]
        magn_noise = 0.1                        % [μTesla^2]
        magn_disturbance_noise = 0.5            % [μTesla^2]
        magn_disturbance_decay_factor = 0.5     % if the magnetic disturbance is quickly changing set to a low value; ∈ [0, 1]
        magnetic_field_limits = [  0.75,  1.5;  % [%] and [°] if the norm of the measured magnetometer and the inclination angle
                                 -15,    15]    % ∈ to this interval, these measures are used to correct the orientation estimate
        q_sens_magn = quaternion([1 0 0 0])     % orientation of the magnetometer sensor frame wrt body frame
        
        % GPS
        GPS_sample_rate = 5                     % [Hz]
        GPS_pos_noise = 1                       % [m^2]
        GPS_pos_drift_noise = 0.1               % [m^2]
        GPS_vel_noise = 0.1                     % [(m/s)^2]
        
        % UWB
        uwb_sample_rate = 40                    % [Hz]
        uwb_noise = 0.01                        % [m^2]
        uwb_beacon_position                     % [m]
        uwb_beacon_id                           % 
        
        % Vision
        vis_sample_rate = 50                    % [Hz]
        camera_orient                           % euler angles [yaw, pitch, roll] [rad]
        camera_pos                              % camera position p_cb_b [m]
        marker_id
        marker_orient                           % euler angles [yaw, pitch, roll] [rad]
        marker_pos                              % p_mb_b
        vision_pos_noise
        vision_orient_noise
        
        % Barometer
        bar_sample_rate = 1                     % [Hz]
        bar_noise = 1                           % [m^2]
        
        % Altimeter
        alt_sample_rate = 100                   % [Hz]
        alt_pos = [0, 0, 0.1]                   % p_ab_b [m]
        alt_noise = 0.005                       % [m^2]
        
        alt_threshold = 0.3                     % [m] altimeter threshold: if the measure of the altitude by the altimeter and and its estimate
                                                % differs by more than this value, it is assumed that there was a sudden ground height change.
        ground_height_noise = 1e-1              % [m^2] process noise of the ground altitude process
        
        init_process_noise = diag([6.092348396e-6*ones(1,3), ...
                                   7.6154354947e-5*ones(1,3), ...
                                   9.62361e-3*ones(1,3), ...
                                   0.6*ones(1,3), ...
                                   ones(1,3), ...
                                   ones(1,3), ...
                                   ones(1,3), ...
                                   ones(1,3), ...
                                   ones(1,1)])
        
        % Earth parameters
        magn_field_NED                          % [μTesla]
        gravity = 9.81                          % [m/s]
        reference_location                      % latitude, longitude [°], altitude [m]
    end
    
    properties (Nontunable)
        
    end
    
    
    %% Discrete State
    
    properties(DiscreteState)
        % Error state: x_corr = [theta; b; a; d; p; v; b_a]
        %          ⌈ orientation error          ⌉   ⌈ θ_ε   ⌉
        %          | gyroscope bias error       |   | ω_b_ε |
        %          | linear acceleration error  |   | acc_ε |
        % x_corr = | magnetic disturbance error | = | d_ε   |  ∈  R^22
        %          | position error             |   | p_ε   |
        %          | velocity error             |   | v_ε   |
        %          ⌊ accelerometer bias error   ⌋   ⌊ a_b_ε ⌋
        %          ⌊ ground altitude error      ⌋   ⌊ h_g__ε ⌋
        x_corr
        
        % Orientation (quaternion form)
        q
        
        % Gravity vector estimates
        g_accel             % Gravity vector estimated from the accelerometer
        store_accel         % Accelerations measurement store variable
        g_gyro              % Gravity vector estimated from the gyroscope predicted orientation
        accel_corr_flag     % True if the current accelerometer measure is NOT suitable to correct the current orientation
        
        % Magnetic field estimates
        m_magn              % Magnetic vector estimated from the magnetometer
        m_gyro              % Magnetic vector estimated from the gyroscope predicted orientation
        magn_corr_flag      % True if the current magnetometer measure is NOT suitable to correct the current orientation
        
        % Gyroscope drift estimate
        gyro_offset
        
        % Estimate of the linear acceleration of the IMU (no gravity)
        lin_accel_prior
        
        % Magnetic disturbance vector error in sensor frame
        magn_dist
        
        % Position
        pos
        
        % Velocity
        vel
        
        % Accelerometer bias
        acc_bias
        
        % Ground height
        ground_height
        
        % GPS position drift estimate
        GPS_pos_drift
        
        % Kalman filter matrices
        P
        
        % Parameters used for predict_P_1
        time_last_orient_corr       % Time elapsed since the last orientation correction
        
        % Parameters used for predict_P_2
        time_last_pos_corr          % Time elapsed since the last position (and velocity) correction
        P_31_GPS
        P_34_GPS
    end

    % Pre-computed constants
    properties(Access = private)
        % Sensors sampling time
        sample_time
        imu_Ts      % decimation_factor / sample_time
        magn_Ts
        GPS_Ts
        uwb_Ts
        vis_Ts
        bar_Ts
        alt_Ts
        
        % Covariance of the measurement model
        R
        
        % Vision
        quat_gm        % quaternion orientation marker to global
        quat_cb        % quaternion orientation body to camera
        
        pos_bc_b
        pos_mg_g
    end

    
    %% Public Methods
    
    methods
        % Constructor
        function obj = my_navigation_filter(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(obj,nargin,varargin{:})
            
            % private_properties_update(obj)    % Used in version 1, in version 2 produces errors because the parameters are specified after the creation fo the object
        end
        
        % Set the initial DiscreteState properties.
        % To be used if additional informations are available, for example
        % from an initial calibration.
        function set_initial_state(obj, varargin)
            dec_max = obj.decimation_factor_max;
            
            for ii = 1:2:nargin-1
                switch varargin{ii}
                    case 'q'
                        obj.q = varargin{ii+1} * ones(dec_max, 1);
                    case 'gyro_offset'
                        obj.gyro_offset = varargin{ii+1};
                    case 'magn_dist'
                        obj.magn_dist = varargin{ii+1};
                    case 'pos'
                        obj.pos = varargin{ii+1};
                    case 'vel'
                        obj.vel = varargin{ii+1};
                    case 'acc_bias'
                        obj.acc_bias = varargin{ii+1};
                end
            end
        end
        
        % Predict the orientation, the position and the velocity using the
        % accelerometer and the gyroscope measurements.
        function [q_gyro_out, pos, vel] = predict(obj, gyro_meas, acc_meas)
            % Rotate the measure from its sensor frame to the body frame
            acc_meas = obj.quat_rot(acc_meas, obj.q_sens_acc);
            gyro_meas = obj.quat_rot(gyro_meas, obj.q_sens_gyro);
            
            
            % Orientation prediction
            q_gyro_out = gyro_orient_prediction(obj, gyro_meas.');
            
            % Position and velocity prediction
            acc_meas = acc_meas.' + obj.acc_bias;
            [pos, vel] = imu_pos_vel_prediction(obj, acc_meas);
            pos = pos.';        % the output is a row vector
            vel = vel.';        % the output is a row vector
            
            
            % The previous (decimation_factor_max) accelerations are stored
            % in the store_accel variable because they all are used in the
            % orientation correction step using the accelerometers, done at
            % a lower frequency compared to the accelerometer frequency.
            % This is done to smooth out the accelerometer noise, and
            % should be an acceptable procedure in the case of "slowly"
            % turning vehicles.
            obj.store_accel(:,1:end-1) = obj.store_accel(:,2:end);
            obj.store_accel(:,end) = acc_meas;
        end
        
        % Correct the estimate using the accelerometer.
        function [q_imu_out, z_g] = fuse_accel(obj)
            z_g = imu_model(obj);
            
            imu_kalman(obj, z_g);
            
            %flag = accel_corr_check(obj);
            
            %if not(flag)
                % The correction is executed
                q_imu_out = imu_correct(obj);
            %else
                % The correction is NOT executed
                %q_imu_out = obj.q(end);
            %end
        end
        
        % Correct the estimate using the magnetometer.
        function [q_magn_out, z_m] = fuse_magn(obj, magn_meas)
            % Rotate the measure from its sensor frame to the body frame
            magn_meas = obj.quat_rot(magn_meas, obj.q_sens_magn);
            
            
            z_m = magn_model(obj, magn_meas.');
            
            magn_kalman(obj, z_m);
            
            q_magn_out = magn_correct(obj);
        end
        
        % Correct the estimate of the position and velocity using the GPS
        % measurements (of position and velocity).
        function [pos, vel, z_GPS] = fuse_GPS(obj, GPS_pos_meas, GPS_vel_meas)
            z_GPS = GPS_model(obj, GPS_pos_meas.', GPS_vel_meas.');
            
            GPS_kalman(obj, z_GPS);
            
            [pos, vel] = GPS_correct(obj);
            pos = pos.';
            vel = vel.';
        end
        
        % Correct using the UWB measurements.
        function [pos, vel] = fuse_uwb(obj, uwb_meas, id)
            [z_uwb, diff_imu] = uwb_model(obj, uwb_meas, id);
            
            uwb_kalman(obj, z_uwb, diff_imu, uwb_meas);
            
            [pos, vel] = uwb_correct(obj);
            pos = pos.';
            vel = vel.';
        end
        
        % Correct using the "unknown" UWB measurements.
        function [pos, vel] = fuse_unknown_uwb(obj, uwb_meas, beacon_pos, dir, rnk)
            [z_uwb, diff_imu] = uwb_unkn_model(obj, uwb_meas, beacon_pos);
            
            uwb_kalman(obj, z_uwb, diff_imu, uwb_meas);
            
            [pos, vel] = uwb_unkn_correct(obj, dir, rnk);
            pos = pos.';
            vel = vel.';
        end
        
        % Correct using the vision measurements.
        function [q_corr, pos_corr, vel_corr, z_vis] = fuse_vis(obj, Tmc, id)
            [z_vis, n_meas] = vis_model(obj, Tmc, id);
            
            vis_kalman(obj, z_vis, n_meas);
            
            [q_corr, pos_corr, vel_corr] = vis_correct(obj);
            pos_corr = pos_corr.';
            vel_corr = vel_corr.';
        end
        
        % Correct using the barometer measurements.
        function [h, z_bar] = fuse_bar(obj, bar_meas)
            z_bar = bar_model(obj, bar_meas);
            
            if isnan(z_bar)
                h = obj.pos(3);
            else
                bar_kalman(obj, z_bar);
            
                h = bar_correct(obj);  
            end
        end
        
        % Correct using the altimeter measurements.
        function [h, ground_height, z_alt] = fuse_alt(obj, alt_meas)
            z_alt = alt_model(obj, alt_meas);
            
            if isnan(z_alt)
                h = obj.pos(3);
                ground_height = obj.ground_height;
            elseif abs(z_alt) > obj.alt_threshold
                % The altimeter is used only to update the estimate of the
                % ground height.
                
                h = obj.pos(3);
                
                obj.ground_height = obj.ground_height - z_alt;
                ground_height = obj.ground_height;
            else
                alt_kalman(obj, z_alt);
            
                [h, ground_height] = alt_correct(obj);  
            end
        end
        
        % Error estimate covariance prediction part 1 (for the orientation)
        % This and part 2 will be called separately :D
        function predict_P_1(obj)
            kk = obj.time_last_orient_corr;
            
            P_corr = obj.P(1:12, 1:12);
            
            P1 = diag(diag(P_corr(1:3,1:3)));
            P2 = diag(diag(P_corr(4:6,4:6)));
            P3 = diag(diag(P_corr(7:9,7:9)));
            P4 = diag(diag(P_corr(10:12,10:12)));
            
            ni = obj.lin_acc_decay_factor;
            sigma = obj.magn_disturbance_decay_factor;
            beta = obj.gyro_drift_noise;
            eta = obj.gyro_noise;
            xi = obj.lin_acc_noise;
            gamma = obj.magn_disturbance_noise;
            
            Q = [P1 + kk^2*(P2 + (beta + eta)*eye(3)),  -kk*(P2 + beta*eye(3)),   zeros(3,3),              zeros(3,3);
                 -kk*(P2 + beta*eye(3)),                 P2 + beta,               zeros(3,3),              zeros(3,3);
                 zeros(3,3),                             zeros(3,3),              ni^2 * P3 + xi*eye(3),   zeros(3,3);
                 zeros(3,3),                             zeros(3,3),              zeros(3,3),              sigma^2 * P4 + gamma*eye(3)];
            
            obj.P(1:12, 1:12) = Q;
            
            
            % Reset to zero the sum
            obj.time_last_orient_corr = 0;
        end
        
        % Error estimate covariance prediction part 2 (for the position and
        % the velocity). Despite its name, it must be called BEFORE
        % predict_P_1. (ó﹏ò｡)
        % Updates only the part of P associated with the following states:
        % [θ_ε, p_ε, v_ε, a_b_ε, GPS_b_ε].' (GPS_b_ε is not yet used).
        function predict_P_2(obj)
            kk = obj.time_last_pos_corr;
            
            P_corr = [obj.P(1:3,1:3), zeros(3,13);
                      zeros(13,3),    obj.P(13:25,13:25)];
            
            % Noise parameters
            alpha = obj.gyro_noise;
            beta = kk * obj.acc_noise;
            eta = 1/2 * kk^2 * obj.acc_noise;
            xi = obj.acc_drift_noise;
            gamma = obj.GPS_pos_drift_noise;
            
            % Blocks with which the updated covariance matrix is built
            P1_0 = diag(diag(P_corr(1:3,1:3)));
            P1 = diag(diag(P_corr(1:3,1:3))) + alpha * eye(3);
            P2 = diag(diag(P_corr(4:6,4:6))) + eta * eye(3);
            P3 = diag(diag(P_corr(7:9,7:9))) + beta * eye(3);
            P4 = diag(diag(P_corr(10:12,10:12))) + xi * eye(3);
            P5 = diag(diag(P_corr(13:15,13:15))) + gamma * eye(3);
            P_6 = P_corr(16,16) + obj.ground_height_noise;
            
            P_31 = obj.P_31_GPS;    % Σ ( skew(Rnb * acc) * Ts )
            P_34 = obj.P_34_GPS;    % Σ ( Rnb * Ts )
            
%             Q = [P1_0,          zeros(3,3),       P_31 * P1,                       zeros(3,3),   zeros(3,3);
%                  zeros(3,3),    P2 + P3 * kk^2,   P3 * kk,                         zeros(3,3),   zeros(3,3);
%                  P_31 * (P1),   P3 * kk,          P3 + P_31*P_31*P1 + P_34 * P4,   P_34 * P4,    zeros(3,3);
%                  zeros(3,3),    zeros(3,3),       P_34 * P4,                       P4,           zeros(3,3);
%                  zeros(3,3),    zeros(3,3),       zeros(3,3),                      zeros(3,3),   P5];
            
            % Temporary, 
            Q = [P1_0,            zeros(3,3),       P_31 * P1*0,                                 zeros(3,3),   zeros(3,3),   zeros(3,1);
                 zeros(3,3),      P2 + P3 * kk^2,   P3 * kk,                                     zeros(3,3),   zeros(3,3),   zeros(3,1);
                 P_31 * (P1)*0,   P3 * kk,          P3 + P_31*P_31*P1*0 + P_34 * P4 * P_34.',   -P_34 * P4,    zeros(3,3),   zeros(3,1);
                 zeros(3,3),      zeros(3,3),       -P4 * P_34.',                                P4,           zeros(3,3),   zeros(3,1);
                 zeros(3,3),      zeros(3,3),       zeros(3,3),                                  zeros(3,3),   P5,           zeros(3,1);
                 zeros(1,3),      zeros(1,3),       zeros(1,3),                                  zeros(1,3),   zeros(1,3),   P_6];
            
            % Set the updated P matrix
            obj.P(1:3, 13:25) = Q(1:3, 4:16);
            obj.P(13:25, 1:3) = Q(4:16, 1:3);
            obj.P(13:25, 13:25) = Q(4:16, 4:16);
            
            
            % Reset to zero the sum
            obj.time_last_pos_corr = 0;
            obj.P_31_GPS = zeros(3,3);
            obj.P_34_GPS = zeros(3,3);
        end
        
        % To be executed after changing one of the relevant properties of
        % the filter.
        function private_properties_update(obj)
            % Time constants definition.
            obj.sample_time = 1 / obj.sample_rate;
            obj.imu_Ts = obj.decimation_factor / obj.sample_rate;
            obj.magn_Ts = 1 / obj.magn_sample_rate;
            obj.GPS_Ts = 1 / obj.GPS_sample_rate;
            obj.uwb_Ts = 1 / obj.uwb_sample_rate;
            obj.vis_Ts = 1 / obj.vis_sample_rate;
            obj.bar_Ts = 1 / obj.bar_sample_rate;
            obj.alt_Ts = 1 / obj.alt_sample_rate;
            
            
            % Covariance of the measurement model.
            acc_n = (obj.acc_noise + obj.lin_acc_noise + obj.imu_Ts^2 * (obj.gyro_noise + obj.gyro_drift_noise)) * ones(1,3);
            magn_n = (obj.magn_noise + obj.magn_disturbance_noise + obj.magn_Ts^2 * (obj.gyro_noise + obj.gyro_drift_noise)) * ones(1,3);
            
            pos_gps_n = (obj.GPS_pos_noise + obj.GPS_pos_drift_noise + obj.GPS_Ts^4 / 4 * (obj.acc_noise + obj.acc_drift_noise)) * ones(1,3);
            vel_gps_n = (obj.GPS_vel_noise + obj.GPS_Ts^2 * (obj.acc_noise + obj.acc_drift_noise)) * ones(1,3);
            
            pos_uwb_n = obj.uwb_noise + obj.uwb_Ts^4 / 4 * (obj.acc_noise + obj.acc_drift_noise);
            
            pos_vis_n = (obj.vision_pos_noise + obj.vis_Ts^4 / 4 * (obj.acc_noise + obj.acc_drift_noise));
            orient_vis_n = (obj.vision_orient_noise + obj.vis_Ts^2 * (obj.gyro_noise + obj.gyro_drift_noise));
            
            bar_n = obj.bar_noise + obj.bar_Ts^4 / 4 * (obj.acc_noise + obj.acc_drift_noise);
            alt_n = obj.alt_noise + obj.alt_Ts^4 / 4 * (obj.acc_noise + obj.acc_drift_noise);
            
            obj.R = diag([acc_n, magn_n, pos_gps_n, vel_gps_n, pos_uwb_n, pos_vis_n, orient_vis_n, bar_n, alt_n]);
            
            
            % Vision useful quantities
            if  not(isempty(obj.marker_orient))
                obj.quat_cb = conj(quaternion(eul2quat(obj.camera_orient)));
                obj.quat_gm = quaternion(eul2quat(obj.marker_orient));
            
                obj.pos_bc_b = - obj.camera_pos.';
                obj.pos_mg_g = obj.marker_pos.';
            end
        end
    end

    
    %% Protected Methods
    
    methods(Access = protected)
        %% Basic Functions
        
        function setupImpl(~)
            % Perform one-time calculations, such as computing constants
        end

        function y = stepImpl(~, u)
            % Implement algorithm. Calculate y as a function of input u and discrete states.
            y = u;
        end
        
        function resetImpl(obj)
            % Initialize / reset discrete-state properties
            dec_max = obj.decimation_factor_max;
            
            obj.x_corr = zeros(25,1);
        
            obj.q = quaternion([1,0,0,0]) * ones(dec_max, 1);
            
            obj.g_accel = zeros(3,1);
            obj.store_accel = zeros(3,dec_max);
            obj.g_gyro = zeros(3,1);
            obj.accel_corr_flag = false;
            
            obj.m_magn = zeros(3,1);
            obj.m_gyro = zeros(3,1);
            obj.magn_corr_flag = false;
            
            obj.gyro_offset = zeros(3,1);
            
            obj.lin_accel_prior = zeros(3,1);
            
            obj.magn_dist = zeros(3,1);
            
            obj.pos = zeros(3,1);
            
            obj.vel = zeros(3,1);
            
            obj.acc_bias = zeros(3,1);
            
            obj.ground_height = 0;
            
            obj.GPS_pos_drift = zeros(3,1);
            
            obj.P = obj.init_process_noise;
            
            obj.time_last_orient_corr = 0;
            
            obj.time_last_pos_corr = 0;
            
            obj.P_31_GPS = zeros(3,3);
            obj.P_34_GPS = zeros(3,3);
        end
        
        
        %% Backup/Restore Functions
        
        function s = saveObjectImpl(obj)
            % Set properties in structure s to values in object obj

            % Set public properties and states
            s = saveObjectImpl@matlab.System(obj);

            % Set private and protected properties
            %s.myproperty = obj.myproperty;
        end

        function loadObjectImpl(obj,s,wasLocked)
            % Set properties in object obj to values in structure s

            % Set private and protected properties
            % obj.myproperty = s.myproperty; 

            % Set public properties and states
            loadObjectImpl@matlab.System(obj,s,wasLocked);
        end
        

        %% Advanced Functions
        
        % Not really needeed...
        
%         function validateInputsImpl(obj,u)
%             % Validate inputs to the step method at initialization
%         end
% 
%         function validatePropertiesImpl(obj)
%             % Validate related or interdependent property values
%         end

        % Use the getDiscreteState method to ... (suspance)
        % get the discrete state.
%         function ds = getDiscreteStateImpl(obj)
%             % Return structure of properties with DiscreteState attribute
%             ds = struct();
%         end

%         function processTunedPropertiesImpl(obj)
%             % Perform actions when tunable properties change
%             % between calls to the System object
%         end
% 
%         function flag = isInputSizeMutableImpl(obj,index)
%             % Return false if input size cannot change
%             % between calls to the System object
%             flag = false;
%         end
% 
%         function flag = isInactivePropertyImpl(obj,prop)
%             % Return false if property is visible based on object 
%             % configuration, for the command line and System block dialog
%             flag = false;
%         end
        
        
        %% Accelerometer and Gyroscope Fusion
        
        function q_out = gyro_orient_prediction(obj, gyro_meas)
            Ts = obj.sample_time;
            
            ang_vel = gyro_meas - obj.gyro_offset;
            
            % Predict the new orientation using the gyroscope measurements (and the gyroscope offset).
            q_out = obj.quat_updt(obj.q(end), ang_vel, Ts);
            
            % Keep track of the previous (max_decimation_factor) orientations.
            obj.q(1:end-1) = obj.q(2:end);
            % Save the new orientation
            obj.q(end) = q_out;
            
            % 
            obj.time_last_orient_corr = obj.time_last_orient_corr + Ts;
        end
        
        % IMU sensor error model
        function z_g = imu_model(obj)
            dec = obj.decimation_factor;
            
            % Estimate gravity from orientation.
            if dec == 1
                q_avg = obj.q(end);
            else
                q_avg = meanrot([obj.q(end-dec+1), obj.q(end)]);        % TODO: high computational cost, simplify it
                %q_avg = obj.q(end-dec+1) + obj.q(end);
                %q_avg = 1/norm(q_avg) * q_avg; 
            end
            
            obj.g_gyro = (quat2rotm(q_avg).' * [0; 0; 1]);
            
            % Estimate gravity from acceleration.
            obj.g_accel = mean(obj.store_accel.').' - obj.lin_accel_prior;
            if not(norm(obj.g_accel) == 0)
                obj.g_accel = obj.g_accel / norm(obj.g_accel);
            end
                        
            % Error model
            z_g = obj.g_accel - obj.g_gyro;
        end
        
        function imu_kalman(obj, z_g)
            % Kalman equations are simplified because of the choice of the
            % error state.
            
            kk = obj.imu_Ts;
            
            % Observation model
            % States: [θ_ε, ω_b_ε, acc_ε].'
            H_1 = [-skew(obj.g_gyro),  skew(kk*obj.g_gyro),  eye(3)];
            
            % Observation model covariance
            R_1 = obj.R(1:3,1:3);
            
            P_pre = obj.P(1:9, 1:9);
            
            % Kalman equations
            [x_cor, P_cor] = obj.kalman_eq(P_pre, R_1, H_1, z_g);
            
            obj.x_corr(1:9) = x_cor;
            obj.P(1:9, 1:9) = P_cor;
        end
        
        function q_out_corr = imu_correct(obj)
            % Correct the estimate of the orientation.
            q_out_corr = obj.q(end) * quaternion(- obj.x_corr(1:3).', 'rotvec');
            obj.q(end) = q_out_corr;
            
            % Correct the estimate of the gyroscope offset.
            obj.gyro_offset = obj.gyro_offset - obj.x_corr(4:6);
            
            % Correct the estimate of the linear acceleration.
            obj.lin_accel_prior = obj.lin_acc_decay_factor * (obj.lin_accel_prior - obj.x_corr(7:9));
        end
        
        function flag = accel_corr_check(obj)
            % Calculates the mean of the norm of the (decimation_factor)
            % previous accelerometer measurements.
            norm_g_meas = mean(sqrt(sum(obj.store_accel.^2,2)), 1);
            
            % Measured gravity norm divided by the expectedgravity norm
            ratio = norm_g_meas / obj.gravity;
            
            % It the measured norm is outside the predefined margins the
            % accelerometers measure is not used to estimate the
            % orientation, this because it is subject to big accelerations
            % which alters considerably its measure.
            if (ratio < obj.gravity_limits(1)) || (ratio > obj.gravity_limits(2))
                flag = true;
            else
                flag = false;
            end
            
            obj.accel_corr_flag = flag;
        end
        
        
        %% Magnetometer Correction
        
        % Magnetometer error model
        function z_m = magn_model(obj, magn_meas)
            % Estimate of the magnetic vector using the predicted
            % orientation.
            obj.m_gyro = (quat2rotm(obj.q(end))).' * obj.magn_field_NED;
            m_gyro_normalized = obj.m_gyro / norm(obj.m_gyro);
            
            % Estimate of the magnetic field using the magnetometer.
            magn_meas = magn_meas - obj.magn_dist;
            magn_meas_normalized = magn_meas / norm(magn_meas);
            
            % Error model (with normalized magnetic field)
            z_m = magn_meas_normalized - m_gyro_normalized;
        end
        
        % Second step of the sequential Kalman filter.
        function magn_kalman(obj, z_m)
            kk = obj.magn_Ts;
            
            % Measurement matrix
            m_gyro_normalized = obj.m_gyro / norm(obj.m_gyro);
            
            H_2 = [-skew(m_gyro_normalized),  skew(kk*m_gyro_normalized),  eye(3)];
            
            % Observation model covariance
            R_2 = obj.R(4:6,4:6);
            
            % Kalman equations
            P_pre = obj.P;
            P_pre = [P_pre(1:6, 1:6), zeros(6,3);
                     zeros(3,6),  P_pre(10:12,10:12)];

            [x_cor, P_cor] = obj.kalman_eq(P_pre, R_2, H_2, z_m);
            
            obj.x_corr(1:6) = x_cor(1:6);
            obj.x_corr(10:12) = x_cor(7:9);
            
            obj.P(1:6, 1:6) = P_cor(1:6, 1:6);
            obj.P(10:12, 10:12) = P_cor(7:9, 7:9);
        end
        
        function q_out_corr = magn_correct(obj)
            % Correct the estimate of the orientation.
            q_out_corr = obj.q(end) * quaternion(- obj.x_corr(1:3).', 'rotvec');
            obj.q(end) = q_out_corr;
            
            % Correct the estimate of the gyroscope offset.
            obj.gyro_offset = obj.gyro_offset - obj.x_corr(4:6);
            
            % Correct the estimate of the magnetic disturbance.
            obj.magn_dist = obj.magn_disturbance_decay_factor * ( obj.magn_dist - obj.x_corr(10:12) );
        end
        
        
        %% GPS Correction
        
        function [pos_out, vel_out] = imu_pos_vel_prediction(obj, acc_meas)
            q_corr = obj.q(end);
            g = - obj.gravity * [0; 0; 1];
            Ts = obj.sample_time;
            
            acc_meas = - acc_meas;
            
            % Quaternion rotation to global frame
            [~, part1, part2, part3] = parts(q_corr * quaternion([0; acc_meas].') * conj(q_corr));
            
            vel_old = obj.vel;      % velocity at the previous time step
            
            % Prediction using the IMU measurements
            vel_out = vel_old + (([part1, part2, part3] - g.') * Ts).';
            obj.vel = vel_out;
            
            pos_out = obj.pos + (vel_old + vel_out) / 2 * Ts;       % equivalent to doing p = p0 + v*t + 1/2*a*T^2
            obj.pos = pos_out;
            
            
            % Update some quantities used for the prediction of P
            Rnb = quat2rotm(q_corr);
            
            obj.P_34_GPS = obj.P_34_GPS + Rnb * Ts;
            
            obj.P_31_GPS = obj.P_31_GPS + skew(Rnb * acc_meas) * Ts;
            
            %
            obj.time_last_pos_corr = obj.time_last_pos_corr + Ts;
        end
        
        function z_GPS = GPS_model(obj, GPS_p_meas, GPS_v_meas)
            % Geodetic to NED conversion
            refloc = obj.reference_location;
            lat0 = refloc(1); lon0 = refloc(2); h0 = refloc(3);
            
            [xNorth, yEast, zDown] = geodetic2ned(GPS_p_meas(1), GPS_p_meas(2), GPS_p_meas(3), lat0, lon0, h0, wgs84Ellipsoid);
            
            % IMU prediction
            vel_IMU = obj.vel;
            
            pos_IMU = obj.pos;
            
            % GPS measurement
            vel_GPS = GPS_v_meas;
            
            pos_GPS = [xNorth; yEast; zDown]  - obj.GPS_pos_drift;
            
            % Error vector
            z_pos = pos_GPS - pos_IMU;
            z_vel = vel_GPS - vel_IMU;
            
            z_GPS = [z_pos; z_vel];
        end
        
        function GPS_kalman(obj, z_GPS)
%             % Measurement matrix
%             % TODO: verify it is correct
%             H_3 = [zeros(3,3),  -eye(3),       zeros(3,3),  zeros(3,3);
%                    zeros(3,3),   zeros(3,3),  -eye(3),      zeros(3,3)];
%             
%             % Observation model covariance
%             R_3 = obj.R(7:12,7:12);
%             
%             % Kalman equations
%             P_pre = [obj.P(1:3,1:3),      obj.P(1:3,13:21);
%                      obj.P(13:21,1:3),    obj.P(13:21,13:21)];
%             
%             [x_cor, P_cor] = obj.kalman_eq(P_pre, R_3, H_3, z_GPS);
%             
%             % x_cor = [θ_ε, gyro_bias_ε, pos_ε, vel_ε, accel_bias_ε, GPS_bias_ε].'
%             obj.x_corr(1:3) = x_cor(1:3);
%             obj.x_corr(13:21) = x_cor(4:12);
%             obj.P(1:3,1:3) = P_cor(1:3,1:3);
%             obj.P(13:21,13:21) = P_cor(4:12,4:12);

            % Measurement matrix
            % TODO: verify it is correct
            H_3 = [-eye(3),       zeros(3,3),  zeros(3,3);
                    zeros(3,3),  -eye(3),      zeros(3,3)];
            
            % Observation model covariance
            R_3 = obj.R(7:12,7:12);
            
            % Kalman equations
            P_pre = obj.P(13:21,13:21);
            
            [x_cor, P_cor] = obj.kalman_eq(P_pre, R_3, H_3, z_GPS);
            
            % x_cor_old = [θ_ε, gyro_bias_ε, pos_ε, vel_ε, accel_bias_ε, GPS_bias_ε].'
            obj.x_corr(13:21) = x_cor;
            obj.P(13:21,13:21) = P_cor;
        end
        
        function [pos_corr, vel_corr] = GPS_correct(obj)
            % Correct the estimate of the orientation.
            %q_out_corr = obj.q(end) * quaternion(- obj.x_corr(1:3).', 'rotvec');
            %obj.q(end) = q_out_corr;
            
            % Position
            pos_corr = obj.pos - obj.x_corr(13:15);
            obj.pos = pos_corr;
            
            % Velocity
            vel_corr = obj.vel - obj.x_corr(16:18);
            obj.vel = vel_corr;
            
            % Correct the estimate of the accelerometer offset.
            obj.acc_bias = obj.acc_bias - obj.x_corr(19:21);
        end
        
        
        %% Ultra Wide Band Correction
        
        % Ultra Wide Band error model
        function [z_uwb, diff_imu] = uwb_model(obj, uwb_meas, uwb_id)
            beacon_pos = obj.uwb_beacon_position;
            b_id = obj.uwb_beacon_id;
            target_pos = obj.pos.';
            
            index = [];
            
            % Cycle to determine the indexes of the known beacons
            for kk = 1:length(uwb_id)
                for ii = 1:length(b_id)
                    if uwb_id(kk) == b_id(ii)
                        index(end+1) = ii;
                    end
                end
            end
            
            % Initialization
            dist_imu = zeros(length(index), 1);    % predicted estimate of the distance measured by the uwb
            diff_imu = zeros(length(index), 3);    % difference between the beacon position and the target predicted position
            
            % Cycle for all the beacons which detect the target
            for ii = 1:length(index)
                diff_imu(ii, :) = beacon_pos(index(ii), :) - target_pos;
                
                dist_imu(ii) = norm(beacon_pos(index(ii), :) - target_pos);
            end
            
            % Error
            z_uwb = uwb_meas - dist_imu;
        end
        
        % Step of the sequential Kalman filter.
        function uwb_kalman(obj, z_uwb, diff_imu, uwb_meas)
            % Measurement matrix
            % TODO: verify it is correct
            H_4 = [diff_imu ./ uwb_meas, zeros(length(z_uwb), 3), zeros(length(z_uwb), 3)];
            
            % Observation model covariance
            R_4 = eye(length(z_uwb)) * obj.R(13,13);
            
            % Kalman equations
            P_pre = obj.P;
            P_pre = P_pre(13:21, 13:21);

            [x_cor, P_cor] = obj.kalman_eq(P_pre, R_4, H_4, z_uwb);
            
            obj.x_corr(13:21) = x_cor;
            
            obj.P(13:21, 13:21) = P_cor;
        end
        
        function [pos_corr, vel_corr] = uwb_correct(obj)
            % Correct the estimate of the position.
            pos_corr = obj.pos - obj.x_corr(13:15);
            obj.pos = pos_corr;
            
            % Correct the estimate of the velocity.
            vel_corr = obj.vel - obj.x_corr(16:18);
            obj.vel = vel_corr;
            
            % Correct the estimate of the accelerometer offset.
            obj.acc_bias = obj.acc_bias - obj.x_corr(19:21);
        end
        
        
        %% Unknown Ultra Wide Band Correction
        
        % Ultra Wide Band error model
        function [z_uwb, diff_imu] = uwb_unkn_model(obj, uwb_meas, beacon_pos)
            target_pos = obj.pos.';
            
            % Initialization
            dist_imu = zeros(length(uwb_meas), 1);    % predicted estimate of the distance measured by the uwb
            diff_imu = zeros(length(uwb_meas), 3);    % difference between the beacon position and the target predicted position
            
            % Cycle for all the beacons which detect the target
            for ii = 1:length(uwb_meas)
                diff_imu(ii, :) = beacon_pos(ii, :) - target_pos;
                
                dist_imu(ii) = norm(beacon_pos(ii, :) - target_pos);
            end
            
            % Error
            z_uwb = uwb_meas - dist_imu;
        end
        
        function [pos_corr, vel_corr] = uwb_unkn_correct(obj, dir, rnk)
            switch rnk
                case 1
                    % Correct the estimate of the position.
                    pos_corr = obj.pos - dot(obj.x_corr(13:15), dir(1,1:3)) * dir(1,1:3).';
                    obj.pos = pos_corr;
            
                    % Correct the estimate of the velocity.
                    vel_corr = obj.vel - dot(obj.x_corr(16:18), dir(1,1:3)) * dir(1,1:3).';
                    obj.vel = vel_corr;
            
                    % Correct the estimate of the accelerometer offset.
                    obj.acc_bias = obj.acc_bias - dot(obj.x_corr(19:21), dir(1,1:3)) * dir(1,1:3).';
                case 2
                    % Correct the estimate of the position.
                    pos_corr = obj.pos - dot(obj.x_corr(13:15), dir(1,1:3)) * dir(1,1:3).' - dot(obj.x_corr(13:15), dir(2,1:3)) * dir(2,1:3).';
                    obj.pos = pos_corr;
            
                    % Correct the estimate of the velocity.
                    vel_corr = obj.vel - dot(obj.x_corr(16:18), dir(1,1:3)) * dir(1,1:3).' - dot(obj.x_corr(16:18), dir(2,1:3)) * dir(2,1:3).';
                    obj.vel = vel_corr;
            
                    % Correct the estimate of the accelerometer offset.
                    obj.acc_bias = obj.acc_bias - dot(obj.x_corr(19:21), dir(1,1:3)) * dir(1,1:3).' - dot(obj.x_corr(19:21), dir(2,1:3)) * dir(2,1:3).';
                case 3
                    % Correct the estimate of the position.
                    pos_corr = obj.pos - obj.x_corr(13:15);
                    obj.pos = pos_corr;
            
                    % Correct the estimate of the velocity.
                    vel_corr = obj.vel - obj.x_corr(16:18);
                    obj.vel = vel_corr;
            
                    % Correct the estimate of the accelerometer offset.
                    obj.acc_bias = obj.acc_bias - obj.x_corr(19:21);
            end
        end
        
        
        %% ArUco Vision Sensor Correction
        
        % ArUco vision sensor error model
        function [z_vis, n_meas] = vis_model(obj, Tcm, id)
            p_bc_b = obj.pos_bc_b;
            p_mg_g = obj.pos_mg_g;
            
            q_cb = obj.quat_cb;
            q_gm = obj.quat_gm;
            
            b_id = obj.uwb_beacon_id;
            
            index = [];
            
            for jj = 1:length(id)
                for ii = 1:length(b_id)
                    if b_id(ii) == id(jj)
                        index(end+1) = ii;
                    end
                end
            end
            
            % Number of sensed known ArUco markers
            n_meas = length(index);
            
            % Initialization
            q_gb_vis = quaternion([1 0 0 0]) * ones(n_meas, 1);
            p_bg_g_vis = zeros(3, n_meas);
            
            for ii = 1:n_meas
                q_mc = conj(quaternion(rotm2quat(Tcm(1:3, 1:3, ii))));
                
                q_gb_vis(ii) = q_gm(index(ii)) * q_mc * q_cb;
                
                p_bc_g_quat = q_gb_vis(ii) * quaternion([0, p_bc_b.']) * conj(q_gb_vis(ii));
                [~, part2, part3, part4] = parts(p_bc_g_quat);
                p_bc_g = [part2; part3; part4];
                
                p_cm_m = - Tcm(1:3, 1:3, ii).' * Tcm(1:3, 4, ii);
                p_cm_g_quat = q_gm(index(ii)) * quaternion([0, p_cm_m.']) * conj(q_gm(index(ii)));
                [~, part2, part3, part4] = parts(p_cm_g_quat);
                p_cm_g = [part2; part3; part4];
                
                p_bg_g_vis(:, ii) = p_bc_g + p_cm_g + p_mg_g(:, index(ii));
            end
            
            vis_pos_meas = p_bg_g_vis;
            vis_orient_meas = q_gb_vis;
            
            % Error
            z_pos_vis = vis_pos_meas - obj.pos;
            z_pos_vis = reshape(z_pos_vis, [3*n_meas, 1]);                      % Reshape in the form of a column vector
            
            z_orient_vis = obj.q(end) * conj(vis_orient_meas);
            
            z_orient_vis = reshape(rotvec(z_orient_vis).', [3*n_meas, 1]);      % Reshape in the form of a column vector
            
            z_vis = [z_pos_vis; z_orient_vis];
        end
        
        % Step of the sequential Kalman filter.
        function vis_kalman(obj, z_vis, n_meas)
            % Measurement matrix
            I = zeros(3*n_meas, 3);
            for ii = 1:n_meas
                I(1+(ii-1)*3:(ii)*3, 1:3) = eye(3);
            end
            
            H_5_1 = I * [zeros(3,3),  zeros(3,3),     -eye(3),  zeros(3,3),  zeros(3,3)];
            H_5_2 = I * [   -eye(3),  zeros(3,3),  zeros(3,3),  zeros(3,3),  zeros(3,3)];
            H_5 = [H_5_1; H_5_2];
            
            % Observation model covariance
            RR = obj.R;
            
            R_5 = [eye(3*n_meas) * RR(14,14),   zeros(3*n_meas);
                             zeros(3*n_meas),   eye(3*n_meas) * RR(15,15)];
            
            % Kalman equations
            P_pre = obj.P;
            P_pre = [P_pre(1:6, 1:6),   zeros(6, 9);
                          zeros(9,6),   P_pre(13:21, 13:21)];

            [x_cor, P_cor] = obj.kalman_eq(P_pre, R_5, H_5, z_vis);
            
            % Save in x_corr
            obj.x_corr(1:6) = x_cor(1:6);
            obj.x_corr(13:21) = x_cor(7:15);
            
            % Save in P
            obj.P(1:6, 1:6) = P_cor(1:6, 1:6);
            obj.P(13:21, 13:21) = P_cor(7:15, 7:15);
        end
        
        function [q_corr, pos_corr, vel_corr] = vis_correct(obj)
            % Correct the estimate of the orientation.
            q_corr = obj.q(end) * quaternion(- obj.x_corr(1:3).', 'rotvec');
            obj.q(end) = q_corr;
            
            % Correct the estimate of the gyroscope offset.
            obj.gyro_offset = obj.gyro_offset - obj.x_corr(4:6);
            
            % Correct the estimate of the position.
            pos_corr = obj.pos - obj.x_corr(13:15);
            obj.pos = pos_corr;
            
            % Correct the estimate of the velocity.
            vel_corr = obj.vel - obj.x_corr(16:18);
            obj.vel = vel_corr;
            
            % Correct the estimate of the accelerometer offset.
            obj.acc_bias = obj.acc_bias - obj.x_corr(19:21);
        end
        
        
        %% Barometer Correction
        
        % Barometer error model
        function [z_bar] = bar_model(obj, bar_meas)
            z_bar = - bar_meas - obj.pos(3);
        end
        
        % Step of the sequential Kalman filter.
        function bar_kalman(obj, z_bar)
            % Measurement matrix
            % TODO: verify it is correct
            H_5 = [-1, 0];
            
            % Observation model covariance
            R_5 = obj.R(16,16);
            
            % Kalman equations
            P_pre = obj.P;
            P_pre = [P_pre(15,15), P_pre(15,18);
                     P_pre(18,15), P_pre(18,18)];

            [x_cor, P_cor] = obj.kalman_eq(P_pre, R_5, H_5, z_bar);
            
            % Save in x_corr
            obj.x_corr(15:15) = x_cor(1);
            obj.x_corr(18:18) = x_cor(2);
            
            % Save in P
            obj.P(15,15) = P_cor(1,1);
            obj.P(15,18) = P_cor(1,2);
            obj.P(18,15) = P_cor(2,1);
            obj.P(18,18) = P_cor(2,2);
        end
        
        function h = bar_correct(obj)
            % Correct the estimate of the position.
            h = obj.pos(3) - obj.x_corr(15);
            obj.pos(3) = h;
            
            % Correct the estimate of the velocity.
            vel_corr = obj.vel(3) - obj.x_corr(18);
            obj.vel(3) = vel_corr;
        end
        
        
        %% Altimeter Correction
        
        % Altimeter error model
        function [z_alt] = alt_model(obj, alt_meas)
            if isnan(alt_meas)
                % The altimeter is unable to measure the altitude
                z_alt = NaN;
            else
                % It is considered both the effect of the sensor
                % displacement and of the drone rotation.
                qq = obj.q(end);
                cosine = obj.quat_rot([0 0 1], qq) * [0; 0; 1];
                alt_corr = cosine * alt_meas + obj.quat_rot(obj.alt_pos, qq) * [0; 0; 1];
                
                z_alt = - alt_corr - (obj.pos(3) - obj.ground_height);
            end
        end
        
        % Step of the sequential Kalman filter.
        function alt_kalman(obj, z_alt)
            % Measurement matrix
            H_5 = [-1, 0, +1];
            
            % Observation model covariance
            R_5 = obj.R(17,17);
            
            % Kalman equations
            P_pre = obj.P;
            P_pre = [P_pre(15,15), P_pre(15,18), 0;
                     P_pre(18,15), P_pre(18,18), 0;
                                0,            0, P_pre(25,25)];

            [x_cor, P_cor] = obj.kalman_eq(P_pre, R_5, H_5, z_alt);
            
            % Save in x_corr
            obj.x_corr(15:15) = x_cor(1);
            obj.x_corr(18:18) = x_cor(2);
            obj.x_corr(25:25) = x_cor(3);
            
            % Save in P
            obj.P(15,15) = P_cor(1,1);
            obj.P(15,18) = P_cor(1,2);
            obj.P(18,15) = P_cor(2,1);
            obj.P(18,18) = P_cor(2,2);
            obj.P(25,25) = P_cor(3,3);
        end
        
        function [h, ground_height] = alt_correct(obj)
            % Correct the estimate of the position.
            h = obj.pos(3) - obj.x_corr(15);
            obj.pos(3) = h;
            
            % Correct the estimate of the velocity.
            vel_corr = obj.vel(3) - obj.x_corr(18);
            obj.vel(3) = vel_corr;
            
            % Correct the estimate of the ground height.
            ground_height = obj.ground_height - obj.x_corr(25);
            obj.ground_height = ground_height;
        end
    end
    
    
    %% Static Methods
    
    methods(Static)
        % Quaternion update function, uses the quaternion exponential method.
        function qt_p = quat_updt(qt, omega, Ts)
            qt_p = qt*exp(1/2*Ts*quaternion([0,omega.']));
            
            % The normalization should be unnecessary with this method, it
            % is still used to prevent the accumulation of numerical errors
            % from affecting the quaternion unit norm.
            if (norm(qt_p) == 0)	% this check should also be unnecessary but you never know
                qt_p = quaternion([1, 0, 0, 0]);
            else
                qt_p = 1/norm(qt_p) * qt_p;
            end
        end
        
        % Rotation with quaternions
        function v_out = quat_rot(v, q)
            quat_v = quaternion([0, v(1), v(2), v(3)]);
    
            quat_v_out = q * quat_v * conj(q);
    
            % Quaternion parts extraction
            [~, part1, part2, part3] = parts(quat_v_out);
    
            % With this way, the output is in the same form of the input (row or
            % column vector)
            v(1) = part1;
            v(2) = part2;
            v(3) = part3;
    
            v_out = v;
        end
        
        % Kalman equations.
        function [x_corr, P] = kalman_eq(P, R, H, z)
            % Innovation covariance
            S = R + H * P * H.';
            
            % Kalman gain
            K = P * H.' / S;
            
            % Error estimate covariance update
            P = P - K * H * P;
            
            x_corr = K * z;
        end
    end
 end
