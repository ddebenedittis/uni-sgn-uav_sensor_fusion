classdef detect_marker < matlab.System
    % Kalman filter to estimate the position of an aruco marker using the
    % UAV position estimate and the camera measurements.
    %
    % detect_aruco = detect_marker(...);

    % Public, tunable properties
    properties
        camera_pos = [0 0 0]        % p_cb_b
        
        camera_orient = [0 0 0]     % camera to body euler angles [yaw pitch roll] [rad]
        
        % Process noises
        w_p = 1e-5                  % position
        w_q = 1e-5                  % orientation
        
        % Measurement noises
        v_p = 1e-2                  % position constant
        v_p_lin = 1/20^2            % position linear with distance
        v_q = 1e-2                  % orientation constant
        v_q_lin = 1/20^2            % position linear with distance
    end

    properties(DiscreteState)
        rec_id  % recorded id
        
        p       % position
        q       % orientation
        
        P       % error covariance matrix
    end
    
    % Pre-computed constants
    properties(Access = private)
        pos_bc_b
        quat_cb
    end
    
    methods
        % Constructor
        function obj = detect_marker(varargin)
            % Support name-value pair arguments when constructing object
            setProperties(obj,nargin,varargin{:});
        end
        
        function update_private_properties(obj)
            obj.quat_cb = conj(quaternion(eul2quat(obj.camera_orient)));
            
            obj.pos_bc_b = - obj.camera_pos.';
        end
    end

    methods(Access = protected)
        function setupImpl(~)
            % Perform one-time calculations, such as computing constants
        end

        function [p_corr, q_corr] = stepImpl(obj, Tcm, id, p_bn_n, q_bn)
            % Geometry computations
            q_cb = obj.quat_cb;
            p_bc_b = obj.pos_bc_b;
            
            % Output initialization
            p_corr = zeros(length(id), 3);
            q_corr = quaternion([1 0 0 0]) * zeros(length(id), 1);
            
            for ii = 1:length(id)
                % More geometry, id-dependent
                q_cm = quaternion(rotm2quat(Tcm(1:3, 1:3, ii)));
                p_mc_c = Tcm(1:3,4, ii);

                q_mc = conj(q_cm);

                q_mb = q_mc * q_cb;

                % Measurements
                q_mn_meas = q_mb * q_bn;

                q_nc =  conj(q_bn) * conj(q_cb);

                p_mn_n_meas = obj.quat_rot(p_mc_c, q_nc) + obj.quat_rot(-p_bc_b, conj(q_bn)) + p_bn_n.';


                % Chack wether the marker id belongs to an already seen
                % marker or not.
                if not(ismember(id(ii), obj.rec_id))
                    % If the id is new add a new entry for the discrete
                    % states equal to the actual measure.

                    obj.rec_id(end+1) = id(ii);

                    p_corr(ii,:) = p_mn_n_meas.';
                    obj.p(:, end+1) = p_corr(ii,:).';
                
                    q_corr(ii) = q_mn_meas;
                    obj.q(end+1) = q_corr(ii);

                    if sum(size(obj.P)) == 0
                        obj.P(:,:,1) = eye(6);
                    else
                        obj.P(:,:,end+1) = eye(6);
                    end

                else
                    % The id is not new ==> kalman filter
                    
                    % Find the index corresponding to the id
                    for jj = 1:length(obj.rec_id)
                        if id(ii) == obj.rec_id(jj)
                            index = jj;
                        end
                    end

                    % Measurement = meas_value - predict_value
                    z_p = p_mn_n_meas - obj.p(:, index);
                
                    z_o = rotvec(q_mn_meas * conj(obj.q(index))).';
                
                    z = [z_p; z_o];
                
                
                    % Observation matrix and covariance matrices
                    dist = norm(p_mc_c);
                    
                    H = - eye(6);
                    R = diag([obj.v_p*ones(1,3)+obj.v_p_lin*ones(1,3)*dist^2, obj.v_q*ones(1,3)+obj.v_q_lin*ones(1,3)*dist^2]);
                    Q = diag([obj.w_p*ones(1,3), obj.w_q*ones(1,3)]);
                
                    % Predict P
                    P_pred = obj.P(:,:,index) + Q;
                
                    % Kalman equations
                    [x_cor, P_cor] = obj.kalman_eq(P_pred, R, H, z);
                
                    obj.P(:,:,index) = P_cor;
                
                
                    % Update the state and the output
                    p_corr(ii,:) = (obj.p(:, index) - x_cor(1:3)).';
                    obj.p(:, index) = (p_corr(ii,:)).';
                
                    q_corr(ii) = obj.q(index) * conj(quaternion(x_cor(4:6).', 'rotvec'));
                    obj.q(index) = q_corr(ii);
                end
            end
        end

        function resetImpl(obj)
            % Initialize / reset discrete-state properties
            obj.rec_id = [];
            
            obj.p = [];
            obj.q = quaternion([1 0 0 0]) * [];

            obj.P = [];
        end
    end
    
    methods(Static)
        % Kalman equations.
        function [x_corr, P] = kalman_eq(P, R, H, z)
            % Innovation covariance
            S = R + H * P * H.';
            
            % Kalman gain
            K = P * H.' / S;
            
            % Error estimate covariance update
            P = P - K * H * P;
            
            x_corr = K * z;
        end
        
        function v_out = quat_rot(v, q)
            quat_v = quaternion([0, v(1), v(2), v(3)]);
    
            quat_v_out = q * quat_v * conj(q);
    
            % Quaternion parts extraction
            [~, part1, part2, part3] = parts(quat_v_out);
    
            % With this way, the output is in the same form of the input (row or
            % column vector)
            v(1) = part1;
            v(2) = part2;
            v(3) = part3;
    
            v_out = v;
        end
    end
end
